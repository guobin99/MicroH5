# 一脸通（一卡通）微信端H5应用 - 技术规范

## 技术栈

- **前端框架**: React 18.3.1
- **UI组件库**: Ant Design Mobile 5.39.0
- **图标库**: @ant-design/icons 5.6.1
- **路由**: wouter 3.9.0 (Hash路由模式)
- **样式**: Tailwind CSS V4 (CDN)
- **工具库**: dayjs 1.11.20, qrcode.react 4.2.0
- **类名处理**: clsx 2.1.1, tailwind-merge 3.5.0
- **消息提示**: sonner 2.0.7

## 目录结构

```
src/
├── layouts/
│   └── MainLayout.jsx       # 主布局组件（含底部Tab导航）
├── pages/
│   ├── Home.jsx             # 首页
│   ├── Service.jsx          # 服务页
│   ├── Message.jsx          # 消息页
│   ├── Profile.jsx          # 个人中心
│   ├── Recharge.jsx         # 账户充值
│   ├── PaymentCode.jsx      # 付款码
│   ├── PassCode.jsx         # 通行码
│   ├── ConsumptionRecords.jsx # 消费记录
│   ├── RechargeRecords.jsx  # 充值记录
│   ├── Menu.jsx             # 菜谱查询
│   ├── Order.jsx            # 在线订餐
│   ├── MyOrders.jsx         # 我的订餐
│   ├── VisitorAppointment.jsx # 访客预约
│   ├── VisitorRecords.jsx   # 访客记录
│   ├── Attendance.jsx       # 考勤记录
│   ├── AttendanceApply.jsx  # 考勤申请
│   ├── FaceCollection.jsx   # 人脸采集
│   ├── BindAccount.jsx      # 账户绑定
│   ├── CardManage.jsx       # 卡片管理
│   ├── PasswordManage.jsx   # 密码管理
│   ├── Feedback.jsx         # 意见反馈
│   └── NotFound.jsx         # 404页面
├── lib/
│   └── utils.js             # 工具函数
├── App.jsx                  # 应用入口
└── index.jsx                # 渲染入口
```

## 数据存储

- 当前使用浏览器本地状态管理（React useState）
- 预留接口对接后端API
- 支持后续接入Appwrite或Supabase实现数据持久化

## 用户认证

- 支持微信授权登录（预留接口）
- 账户绑定验证（姓名+工号+手机号+验证码）
- 登录态本地管理

## 依赖服务

- 微信支付接口（预留）
- 一脸通平台API（预留）
- 微信JSSDK（预留）

## 架构说明

- 采用单页应用（SPA）架构
- Hash路由模式，适配微信公众号环境
- 组件化开发，页面级组件独立管理
- 模拟数据展示，接口层可无缝替换

## 使用的 Skills

- 无需额外Skill，纯前端实现

## 其它

- 所有金额单位：人民币元
- 时间格式：YYYY-MM-DD HH:mm
- 二维码刷新间隔：60秒
- 支持iOS/Android微信内置浏览器
