﻿import React from 'react';
import { useLocation } from 'wouter';
import {
  Card,
  Grid,
  Badge,
  Avatar,
  Space,
  Tag,
  Button
} from 'antd-mobile';
import {
  PayCircleOutlined,
  QrcodeOutlined,
  GatewayOutlined,
  CoffeeOutlined,
  UserAddOutlined,
  CalendarOutlined,
  CameraOutlined,
  RightOutlined,
  BellOutlined
} from '@ant-design/icons';

interface QuickAction {
  icon: React.ReactNode;
  text: string;
  color: string;
  path: string;
}

interface MenuItem {
  name: string;
  price: string;
  tag: string;
}

const quickActions: QuickAction[] = [
  { icon: <PayCircleOutlined />, text: '充值', color: '#1677ff', path: '/recharge' },
  { icon: <QrcodeOutlined />, text: '付款码', color: '#52c41a', path: '/payment-code' },
  { icon: <GatewayOutlined />, text: '通行码', color: '#722ed1', path: '/pass-code' },
  { icon: <CoffeeOutlined />, text: '订餐', color: '#fa8c16', path: '/menu' },
  { icon: <UserAddOutlined />, text: '访客', color: '#eb2f96', path: '/visitor-appointment' },
  { icon: <CalendarOutlined />, text: '考勤', color: '#13c2c2', path: '/attendance' },
  { icon: <CameraOutlined />, text: '人脸采集', color: '#f5222d', path: '/face-collection' },
  { icon: <RightOutlined />, text: '更多', color: '#8c8c8c', path: '/service' },
];

const todayMenu: MenuItem[] = [
  { name: '红烧肉', price: '12', tag: '荤' },
  { name: '清炒时蔬', price: '6', tag: '素' },
  { name: '番茄炒蛋', price: '8', tag: '半荤' },
  { name: '紫菜蛋花汤', price: '3', tag: '汤' },
];

export default function Home(): React.JSX.Element {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50 pb-16">
      {/* Header */}
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 px-4 pt-12 pb-6 rounded-b-3xl">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <Avatar src="" className="w-12 h-12 border-2 border-white" />
            <div className="text-white">
              <div className="font-medium">张三</div>
              <div className="text-xs text-blue-100">技术部 · 工程师</div>
            </div>
          </div>
          <Badge content={5}>
            <Button
              className="!bg-white/20 !border-0"
              onClick={() => setLocation('/message')}
            >
              <BellOutlined className="text-white text-lg" />
            </Button>
          </Badge>
        </div>

        {/* Balance Card */}
        <Card className="!rounded-2xl !shadow-lg">
          <div className="flex items-center justify-between">
            <div>
              <div className="text-gray-500 text-sm mb-1">账户余额</div>
              <div className="text-3xl font-bold text-gray-800">
                <span className="text-lg">¥</span>256.80
              </div>
              <div className="text-xs text-gray-400 mt-1">卡号: 8888****1234</div>
            </div>
            <Button
              color="primary"
              fill="solid"
              className="!rounded-full"
              onClick={() => setLocation('/recharge')}
            >
              立即充值
            </Button>
          </div>
        </Card>
      </div>

      {/* Quick Actions */}
      <div className="px-4 mt-4">
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="text-sm font-medium text-gray-800 mb-4">常用功能</div>
          <Grid columns={4} gap={8}>
            {quickActions.map((item, index) => (
              <Grid.Item key={index} onClick={() => setLocation(item.path)}>
                <div className="flex flex-col items-center gap-2 py-2">
                  <div
                    className="w-12 h-12 rounded-2xl flex items-center justify-center text-white text-xl"
                    style={{ backgroundColor: item.color }}
                  >
                    {item.icon}
                  </div>
                  <span className="text-xs text-gray-600">{item.text}</span>
                </div>
              </Grid.Item>
            ))}
          </Grid>
        </div>
      </div>

      {/* Today's Menu */}
      <div className="px-4 mt-4">
        <div className="bg-white rounded-2xl p-4 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <div className="text-sm font-medium text-gray-800">今日菜谱</div>
            <Button
              size="mini"
              fill="none"
              className="!text-gray-400"
              onClick={() => setLocation('/menu')}
            >
              查看更多 <RightOutlined className="text-xs" />
            </Button>
          </div>
          <Space direction="vertical" className="w-full" gap={12}>
            {todayMenu.map((item, index) => (
              <div key={index} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 bg-orange-100 rounded-lg flex items-center justify-center text-orange-500">
                    <CoffeeOutlined />
                  </div>
                  <div>
                    <div className="text-sm text-gray-800">{item.name}</div>
                    <Tag size="mini" color="default" className="!text-xs">
                      {item.tag}
                    </Tag>
                  </div>
                </div>
                <div className="text-sm font-medium text-orange-500">
                  ¥{item.price}
                </div>
              </div>
            ))}
          </Space>
        </div>
      </div>

      {/* Notice */}
      <div className="px-4 mt-4 mb-4">
        <div className="bg-blue-50 rounded-xl p-3 flex items-center gap-3">
          <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center text-blue-500">
            <BellOutlined />
          </div>
          <div className="flex-1">
            <div className="text-sm text-gray-800">系统通知</div>
            <div className="text-xs text-gray-500">人脸采集功能已上线，请及时完成采集</div>
          </div>
          <RightOutlined className="text-gray-400 text-xs" />
        </div>
      </div>
    </div>
  );
}
