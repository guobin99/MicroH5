import React, { useState } from 'react';
import { Card, List, Badge, Tabs, Empty } from 'antd-mobile';
import {
  BellOutlined,
  PayCircleOutlined,
  CoffeeOutlined,
  UserAddOutlined,
  CalendarOutlined,
  CreditCardOutlined,
  CameraOutlined,
  CheckCircleOutlined,
  ClockCircleOutlined
} from '@ant-design/icons';

interface MessageItem {
  id: number;
  type: string;
  title: string;
  content: string;
  time: string;
  date: string;
  read: boolean;
  icon: React.ReactNode;
  color: string;
}

const messages: MessageItem[] = [
  {
    id: 1,
    type: 'recharge',
    title: '充值到账通知',
    content: '您已成功充值100元，当前余额256.80元',
    time: '10:30',
    date: '今天',
    read: false,
    icon: <PayCircleOutlined />,
    color: '#52c41a'
  },
  {
    id: 2,
    type: 'consumption',
    title: '消费扣款通知',
    content: '您在食堂消费15元，余额241.80元',
    time: '12:15',
    date: '今天',
    read: false,
    icon: <CreditCardOutlined />,
    color: '#fa8c16'
  },
  {
    id: 3,
    type: 'order',
    title: '订餐成功通知',
    content: '您预订的午餐已确认，取餐码：A123',
    time: '09:00',
    date: '今天',
    read: true,
    icon: <CoffeeOutlined />,
    color: '#faad14'
  },
  {
    id: 4,
    type: 'visitor',
    title: '访客审批结果',
    content: '您预约的访客已通过审批',
    time: '14:20',
    date: '昨天',
    read: true,
    icon: <UserAddOutlined />,
    color: '#eb2f96'
  },
  {
    id: 5,
    type: 'attendance',
    title: '考勤异常提醒',
    content: '您今日上班打卡迟到，请及时处理',
    time: '08:35',
    date: '昨天',
    read: true,
    icon: <CalendarOutlined />,
    color: '#f5222d'
  },
  {
    id: 6,
    type: 'face',
    title: '人脸采集审核结果',
    content: '您提交的人脸照片已通过审核',
    time: '16:45',
    date: '前天',
    read: true,
    icon: <CameraOutlined />,
    color: '#13c2c2'
  }
];

export default function Message(): React.JSX.Element {
  const [activeTab, setActiveTab] = useState<string>('all');

  const filteredMessages = activeTab === 'all'
    ? messages
    : messages.filter(m => m.type === activeTab);

  const unreadCount = messages.filter(m => !m.read).length;

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white px-4 py-4 sticky top-0 z-10">
        <div className="text-lg font-medium text-center">
          消息中心
          {unreadCount > 0 && (
            <Badge content={unreadCount} className="ml-2" />
          )}
        </div>
      </div>

      {/* Tabs */}
      <Tabs
        activeKey={activeTab}
        onChange={setActiveTab}
        className="bg-white"
      >
        <Tabs.Tab title="全部" key="all" />
        <Tabs.Tab title="消费" key="consumption" />
        <Tabs.Tab title="订餐" key="order" />
        <Tabs.Tab title="访客" key="visitor" />
        <Tabs.Tab title="考勤" key="attendance" />
      </Tabs>

      {/* Message List */}
      <div className="px-4 pb-20 mt-2">
        {filteredMessages.length > 0 ? (
          <List>
            {filteredMessages.map((message) => (
              <List.Item
                key={message.id}
                prefix={
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white"
                    style={{ backgroundColor: message.color }}
                  >
                    {message.icon}
                  </div>
                }
                className={!message.read ? '!bg-blue-50/50' : ''}
              >
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-medium text-gray-800">{message.title}</span>
                      {!message.read && <Badge dot />}
                    </div>
                    <span className="text-xs text-gray-400">{message.time}</span>
                  </div>
                  <div className="text-sm text-gray-500 mt-1">{message.content}</div>
                  <div className="text-xs text-gray-400 mt-1">{message.date}</div>
                </div>
              </List.Item>
            ))}
          </List>
        ) : (
          <Empty
            image={<BellOutlined className="text-6xl text-gray-300" />}
            description="暂无消息"
            className="mt-20"
          />
        )}
      </div>
    </div>
  );
}
