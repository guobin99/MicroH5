import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Form, Input, Button, DatePicker, Picker, TextArea, Toast, Card, Tabs } from 'antd-mobile';
import { LeftOutlined } from '@ant-design/icons';
import dayjs from 'dayjs';

interface LeaveType {
  label: string;
  value: string;
}

interface ApplyType {
  label: string;
  value: string;
}

const leaveTypes: LeaveType[] = [
  { label: '事假', value: 'personal' },
  { label: '病假', value: 'sick' },
  { label: '年假', value: 'annual' },
  { label: '调休', value: 'compensatory' },
  { label: '婚假', value: 'marriage' },
  { label: '产假', value: 'maternity' },
  { label: '丧假', value: 'bereavement' },
];

const applyTypes: ApplyType[] = [
  { label: '补签申请', value: 'resign' },
  { label: '请假申请', value: 'leave' },
  { label: '异常申诉', value: 'appeal' },
];

export default function AttendanceApply(): JSX.Element {
  const [, setLocation] = useLocation();
  const [form] = Form.useForm();
  const [activeTab, setActiveTab] = useState<string>('resign');
  const [loading, setLoading] = useState<boolean>(false);
  const [leaveTypeVisible, setLeaveTypeVisible] = useState<boolean>(false);
  const [startDateVisible, setStartDateVisible] = useState<boolean>(false);
  const [endDateVisible, setEndDateVisible] = useState<boolean>(false);

  const onSubmit = async (): Promise<void> => {
    try {
      const values = await form.validateFields();
      setLoading(true);

      setTimeout(() => {
        setLoading(false);
        Toast.show({ content: '提交成功', position: 'center' });
        setLocation('/attendance');
      }, 1500);
    } catch (error) {
      Toast.show({ content: '请完善信息', position: 'center' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/attendance')}
        className="bg-white"
      >
        考勤申请
      </NavBar>

      <Tabs
        activeKey={activeTab}
        onChange={setActiveTab}
        className="bg-white"
      >
        <Tabs.Tab title="补签申请" key="resign" />
        <Tabs.Tab title="请假申请" key="leave" />
        <Tabs.Tab title="异常申诉" key="appeal" />
      </Tabs>

      <div className="px-4 py-4">
        <Card className="!rounded-xl">
          <Form
            form={form}
            layout="horizontal"
            footer={
              <Button
                block
                color="primary"
                size="large"
                loading={loading}
                onClick={onSubmit}
                className="!rounded-full mt-4"
              >
                提交申请
              </Button>
            }
          >
            {activeTab === 'resign' && (
              <>
                <Form.Header>补签信息</Form.Header>
                <Form.Item
                  name="date"
                  label="补签日期"
                  rules={[{ required: true, message: '请选择补签日期' }]}
                  onClick={() => setStartDateVisible(true)}
                >
                  <DatePicker
                    visible={startDateVisible}
                    onClose={() => setStartDateVisible(false)}
                    max={new Date()}
                    onConfirm={(val: Date) => {
                      form.setFieldValue('date', dayjs(val).format('YYYY-MM-DD'));
                    }}
                  >
                    {(value: Date | null) => (
                      <Input
                        placeholder="请选择补签日期"
                        readOnly
                        value={value ? dayjs(value).format('YYYY-MM-DD') : ''}
                      />
                    )}
                  </DatePicker>
                </Form.Item>

                <Form.Item
                  name="time"
                  label="补签时间"
                  rules={[{ required: true, message: '请输入补签时间' }]}
                >
                  <Input placeholder="如：08:30" />
                </Form.Item>

                <Form.Item
                  name="type"
                  label="补签类型"
                  rules={[{ required: true, message: '请选择补签类型' }]}
                >
                  <Input placeholder="上班/下班" />
                </Form.Item>

                <Form.Item
                  name="reason"
                  label="补签原因"
                  rules={[{ required: true, message: '请输入补签原因' }]}
                >
                  <TextArea placeholder="请输入补签原因" rows={3} />
                </Form.Item>
              </>
            )}

            {activeTab === 'leave' && (
              <>
                <Form.Header>请假信息</Form.Header>
                <Form.Item
                  name="leaveType"
                  label="请假类型"
                  rules={[{ required: true, message: '请选择请假类型' }]}
                  onClick={() => setLeaveTypeVisible(true)}
                >
                  <Picker
                    columns={[leaveTypes]}
                    visible={leaveTypeVisible}
                    onClose={() => setLeaveTypeVisible(false)}
                    onConfirm={(val: (string | null)[]) => {
                      form.setFieldValue('leaveType', val[0]);
                    }}
                  >
                    {(items: { label: string; value: string }[]) => (
                      <Input
                        placeholder="请选择请假类型"
                        readOnly
                        value={items[0]?.label}
                      />
                    )}
                  </Picker>
                </Form.Item>

                <Form.Item
                  name="startDate"
                  label="开始日期"
                  rules={[{ required: true, message: '请选择开始日期' }]}
                  onClick={() => setStartDateVisible(true)}
                >
                  <DatePicker
                    visible={startDateVisible}
                    onClose={() => setStartDateVisible(false)}
                    onConfirm={(val: Date) => {
                      form.setFieldValue('startDate', dayjs(val).format('YYYY-MM-DD'));
                    }}
                  >
                    {(value: Date | null) => (
                      <Input
                        placeholder="请选择开始日期"
                        readOnly
                        value={value ? dayjs(value).format('YYYY-MM-DD') : ''}
                      />
                    )}
                  </DatePicker>
                </Form.Item>

                <Form.Item
                  name="endDate"
                  label="结束日期"
                  rules={[{ required: true, message: '请选择结束日期' }]}
                  onClick={() => setEndDateVisible(true)}
                >
                  <DatePicker
                    visible={endDateVisible}
                    onClose={() => setEndDateVisible(false)}
                    onConfirm={(val: Date) => {
                      form.setFieldValue('endDate', dayjs(val).format('YYYY-MM-DD'));
                    }}
                  >
                    {(value: Date | null) => (
                      <Input
                        placeholder="请选择结束日期"
                        readOnly
                        value={value ? dayjs(value).format('YYYY-MM-DD') : ''}
                      />
                    )}
                  </DatePicker>
                </Form.Item>

                <Form.Item
                  name="days"
                  label="请假天数"
                  rules={[{ required: true, message: '请输入请假天数' }]}
                >
                  <Input placeholder="请输入请假天数" type="number" suffix="天" />
                </Form.Item>

                <Form.Item
                  name="reason"
                  label="请假事由"
                  rules={[{ required: true, message: '请输入请假事由' }]}
                >
                  <TextArea placeholder="请输入请假事由" rows={3} />
                </Form.Item>
              </>
            )}

            {activeTab === 'appeal' && (
              <>
                <Form.Header>申诉信息</Form.Header>
                <Form.Item
                  name="date"
                  label="申诉日期"
                  rules={[{ required: true, message: '请选择申诉日期' }]}
                  onClick={() => setStartDateVisible(true)}
                >
                  <DatePicker
                    visible={startDateVisible}
                    onClose={() => setStartDateVisible(false)}
                    max={new Date()}
                    onConfirm={(val: Date) => {
                      form.setFieldValue('date', dayjs(val).format('YYYY-MM-DD'));
                    }}
                  >
                    {(value: Date | null) => (
                      <Input
                        placeholder="请选择申诉日期"
                        readOnly
                        value={value ? dayjs(value).format('YYYY-MM-DD') : ''}
                      />
                    )}
                  </DatePicker>
                </Form.Item>

                <Form.Item
                  name="type"
                  label="异常类型"
                  rules={[{ required: true, message: '请选择异常类型' }]}
                >
                  <Input placeholder="迟到/早退/缺卡" />
                </Form.Item>

                <Form.Item
                  name="reason"
                  label="申诉原因"
                  rules={[{ required: true, message: '请输入申诉原因' }]}
                >
                  <TextArea placeholder="请详细说明申诉原因" rows={4} />
                </Form.Item>
              </>
            )}
          </Form>
        </Card>

        <div className="text-xs text-gray-400 mt-4 text-center">
          <div>提交后需等待审批人审批</div>
          <div className="mt-1">每月补签次数上限为3次</div>
        </div>
      </div>
    </div>
  );
}
