import React from 'react';
import { useLocation } from 'wouter';
import { Card, List, Avatar, Tag, Button, Space } from 'antd-mobile';
import {
  UserOutlined,
  CreditCardOutlined,
  LockOutlined,
  CustomerServiceOutlined,
  QuestionCircleOutlined,
  FileTextOutlined,
  RightOutlined,
  EditOutlined,
  LogoutOutlined
} from '@ant-design/icons';

interface MenuItem {
  icon: React.ReactNode;
  text: string;
  color: string;
  path: string;
}

const menuItems: MenuItem[] = [
  {
    icon: <CreditCardOutlined />,
    text: '卡片管理',
    color: '#1677ff',
    path: '/card-manage'
  },
  {
    icon: <LockOutlined />,
    text: '密码管理',
    color: '#722ed1',
    path: '/password-manage'
  },
  {
    icon: <CustomerServiceOutlined />,
    text: '意见反馈',
    color: '#fa8c16',
    path: '/feedback'
  },
  {
    icon: <QuestionCircleOutlined />,
    text: '帮助中心',
    color: '#52c41a',
    path: '/help'
  },
  {
    icon: <FileTextOutlined />,
    text: '用户协议',
    color: '#8c8c8c',
    path: '/agreement'
  }
];

export default function Profile(): React.JSX.Element {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-gradient-to-br from-blue-500 to-blue-600 px-4 pt-12 pb-6">
        <div className="flex items-center gap-4">
          <Avatar src="" className="w-16 h-16 border-2 border-white" />
          <div className="flex-1">
            <div className="text-white font-medium text-lg">张三</div>
            <div className="text-blue-100 text-sm">技术部 · 工程师</div>
            <div className="flex items-center gap-2 mt-2">
              <Tag color="success" fill="outline" className="!text-xs !border-white/30 !text-white">
                已认证
              </Tag>
              <Tag color="warning" fill="outline" className="!text-xs !border-white/30 !text-white">
                人脸已采集
              </Tag>
            </div>
          </div>
          <Button
            fill="none"
            className="!text-white"
            onClick={() => setLocation('/bind-account')}
          >
            <EditOutlined />
          </Button>
        </div>

        {/* Stats */}
        <div className="flex mt-6">
          <div className="flex-1 text-center">
            <div className="text-2xl font-bold text-white">256.80</div>
            <div className="text-xs text-blue-100">账户余额</div>
          </div>
          <div className="w-px bg-white/20" />
          <div className="flex-1 text-center">
            <div className="text-2xl font-bold text-white">8888</div>
            <div className="text-xs text-blue-100">工号</div>
          </div>
          <div className="w-px bg-white/20" />
          <div className="flex-1 text-center">
            <div className="text-2xl font-bold text-white">正常</div>
            <div className="text-xs text-blue-100">账户状态</div>
          </div>
        </div>
      </div>

      {/* Menu */}
      <div className="px-4 pb-20 -mt-4">
        <Card className="!rounded-xl">
          <List>
            {menuItems.map((item, index) => (
              <List.Item
                key={index}
                prefix={
                  <div
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-white"
                    style={{ backgroundColor: item.color }}
                  >
                    {item.icon}
                  </div>
                }
                arrow={<RightOutlined className="text-gray-400" />}
                onClick={() => setLocation(item.path)}
              >
                {item.text}
              </List.Item>
            ))}
          </List>
        </Card>

        {/* Version Info */}
        <div className="text-center text-xs text-gray-400 mt-8">
          <div>版本号: V1.0.0</div>
          <div className="mt-1">一脸通微信端H5</div>
        </div>

        {/* Logout */}
        <Button
          block
          fill="none"
          className="mt-8 !text-red-500"
          onClick={() => setLocation('/bind-account')}
        >
          <LogoutOutlined className="mr-2" />
          退出登录
        </Button>
      </div>
    </div>
  );
}
