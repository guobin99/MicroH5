import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, List, Tag, Empty } from 'antd-mobile';
import { LeftOutlined, PayCircleOutlined, CheckCircleOutlined, ClockCircleOutlined, CloseCircleOutlined } from '@ant-design/icons';

interface Record {
  id: number;
  amount: number;
  channel: string;
  status: 'success' | 'pending' | 'failed';
  statusText: string;
  time: string;
  orderNo: string;
  icon: React.ReactNode;
  color: string;
}

const records: Record[] = [
  {
    id: 1,
    amount: 100.00,
    channel: '微信支付',
    status: 'success',
    statusText: '已到账',
    time: '2026-09-12 10:30',
    orderNo: 'R202609121030001',
    icon: <PayCircleOutlined />,
    color: '#52c41a'
  },
  {
    id: 2,
    amount: 200.00,
    channel: '微信支付',
    status: 'success',
    statusText: '已到账',
    time: '2026-09-10 14:20',
    orderNo: 'R202609101420001',
    icon: <PayCircleOutlined />,
    color: '#52c41a'
  },
  {
    id: 3,
    amount: 50.00,
    channel: '微信支付',
    status: 'pending',
    statusText: '处理中',
    time: '2026-09-08 09:15',
    orderNo: 'R202609080915001',
    icon: <ClockCircleOutlined />,
    color: '#faad14'
  },
  {
    id: 4,
    amount: 100.00,
    channel: '微信支付',
    status: 'failed',
    statusText: '已退款',
    time: '2026-09-05 16:45',
    orderNo: 'R202609051645001',
    icon: <CloseCircleOutlined />,
    color: '#f5222d'
  }
];

interface StatusMap {
  [key: string]: { color: string; text: string };
}

const statusMap: StatusMap = {
  success: { color: 'success', text: '已到账' },
  pending: { color: 'warning', text: '处理中' },
  failed: { color: 'danger', text: '已退款' }
};

export default function RechargeRecords(): React.JSX.Element {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/')}
        className="bg-white"
      >
        充值记录
      </NavBar>

      {/* Summary Card */}
      <Card className="!rounded-xl mx-4 mt-4">
        <div className="flex items-center justify-around">
          <div className="text-center">
            <div className="text-2xl font-bold text-gray-800">450.00</div>
            <div className="text-xs text-gray-500">累计充值</div>
          </div>
          <div className="w-px h-12 bg-gray-200" />
          <div className="text-center">
            <div className="text-2xl font-bold text-green-500">4</div>
            <div className="text-xs text-gray-500">充值次数</div>
          </div>
        </div>
      </Card>

      {/* Records List */}
      <div className="px-4 pb-20 mt-4">
        {records.length > 0 ? (
          <List>
            {records.map((record) => (
              <List.Item
                key={record.id}
                prefix={
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white"
                    style={{ backgroundColor: record.color }}
                  >
                    {record.icon}
                  </div>
                }
                className="!bg-white !mb-2 !rounded-xl"
              >
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <div className="font-medium text-gray-800">
                      +{record.amount.toFixed(2)}
                    </div>
                    <Tag color={statusMap[record.status].color} fill="outline">
                      {statusMap[record.status].text}
                    </Tag>
                  </div>
                  <div className="text-sm text-gray-500 mt-1">{record.channel}</div>
                  <div className="text-xs text-gray-400 mt-1">{record.time}</div>
                  <div className="text-xs text-gray-400 mt-1">订单号: {record.orderNo}</div>
                </div>
              </List.Item>
            ))}
          </List>
        ) : (
          <Empty
            image={<PayCircleOutlined className="text-6xl text-gray-300" />}
            description="暂无充值记录"
            className="mt-20"
          />
        )}
      </div>
    </div>
  );
}
