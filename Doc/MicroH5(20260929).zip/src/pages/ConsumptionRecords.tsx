import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, List, Tabs, Tag, Empty } from 'antd-mobile';
import { LeftOutlined, CreditCardOutlined, CoffeeOutlined, ShoppingOutlined } from '@ant-design/icons';

interface Record {
  id: number;
  type: string;
  title: string;
  location: string;
  amount: number;
  balance: number;
  time: string;
  date: string;
  status: string;
  icon: React.ReactNode;
  color: string;
}

const records: Record[] = [
  {
    id: 1,
    type: 'consumption',
    title: '食堂消费',
    location: '第一食堂',
    amount: -15.00,
    balance: 241.80,
    time: '12:15',
    date: '今天',
    status: 'success',
    icon: <CoffeeOutlined />,
    color: '#fa8c16'
  },
  {
    id: 2,
    type: 'consumption',
    title: '超市购物',
    location: '校园超市',
    amount: -28.50,
    balance: 256.80,
    time: '昨天 18:30',
    date: '昨天',
    status: 'success',
    icon: <ShoppingOutlined />,
    color: '#722ed1'
  },
  {
    id: 3,
    type: 'consumption',
    title: '食堂消费',
    location: '第二食堂',
    amount: -12.00,
    balance: 285.30,
    time: '昨天 12:00',
    date: '昨天',
    status: 'success',
    icon: <CoffeeOutlined />,
    color: '#fa8c16'
  },
  {
    id: 4,
    type: 'order',
    title: '订餐扣款',
    location: '在线订餐',
    amount: -18.00,
    balance: 297.30,
    time: '前天 09:15',
    date: '前天',
    status: 'success',
    icon: <CoffeeOutlined />,
    color: '#faad14'
  },
  {
    id: 5,
    type: 'refund',
    title: '订单退款',
    location: '在线订餐',
    amount: 18.00,
    balance: 315.30,
    time: '2026-09-10',
    date: '9月10日',
    status: 'success',
    icon: <CreditCardOutlined />,
    color: '#52c41a'
  }
];

export default function ConsumptionRecords(): React.JSX.Element {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<string>('all');

  const filteredRecords = activeTab === 'all'
    ? records
    : records.filter(r => r.type === activeTab);

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/')}
        className="bg-white"
      >
        消费记录
      </NavBar>

      {/* Filter Tabs */}
      <Tabs
        activeKey={activeTab}
        onChange={setActiveTab}
        className="bg-white"
      >
        <Tabs.Tab title="全部" key="all" />
        <Tabs.Tab title="消费" key="consumption" />
        <Tabs.Tab title="订餐" key="order" />
        <Tabs.Tab title="退款" key="refund" />
      </Tabs>

      {/* Records List */}
      <div className="px-4 pb-20 mt-2">
        {filteredRecords.length > 0 ? (
          <List>
            {filteredRecords.map((record) => (
              <List.Item
                key={record.id}
                prefix={
                  <div
                    className="w-10 h-10 rounded-full flex items-center justify-center text-white"
                    style={{ backgroundColor: record.color }}
                  >
                    {record.icon}
                  </div>
                }
                className="!bg-white !mb-2 !rounded-xl"
              >
                <div className="flex-1">
                  <div className="flex items-center justify-between">
                    <div className="font-medium text-gray-800">{record.title}</div>
                    <div className={`font-medium ${record.amount > 0 ? 'text-green-500' : 'text-red-500'}`}>
                      {record.amount > 0 ? '+' : ''}{record.amount.toFixed(2)}
                    </div>
                  </div>
                  <div className="flex items-center justify-between mt-1">
                    <div className="text-sm text-gray-500">{record.location}</div>
                    <div className="text-xs text-gray-400">余额: {record.balance.toFixed(2)}</div>
                  </div>
                  <div className="text-xs text-gray-400 mt-1">{record.time}</div>
                </div>
              </List.Item>
            ))}
          </List>
        ) : (
          <Empty
            image={<CreditCardOutlined className="text-6xl text-gray-300" />}
            description="暂无记录"
            className="mt-20"
          />
        )}
      </div>
    </div>
  );
}
