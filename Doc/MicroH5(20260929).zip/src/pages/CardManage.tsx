﻿import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, Button, Toast, Modal, Tag } from 'antd-mobile';
import { LeftOutlined, CreditCardOutlined, LockOutlined, UnlockOutlined, ExclamationCircleOutlined } from '@ant-design/icons';

type CardStatus = 'normal' | 'locked';

export default function CardManage(): JSX.Element {
  const [, setLocation] = useLocation();
  const [cardStatus, setCardStatus] = useState<CardStatus>('normal'); // normal, locked
  const [loading, setLoading] = useState<boolean>(false);

  const handleLock = (): void => {
    Modal.confirm({
      title: '确认挂失',
      content: '挂失后卡片将立即停用，是否继续？',
      onConfirm: () => {
        setLoading(true);
        setTimeout(() => {
          setLoading(false);
          setCardStatus('locked');
          Toast.show({ content: '挂失成功', position: 'center' });
        }, 1500);
      }
    });
  };

  const handleUnlock = (): void => {
    Modal.confirm({
      title: '确认解挂',
      content: '解挂后卡片将恢复正常使用，是否继续？',
      onConfirm: () => {
        setLoading(true);
        setTimeout(() => {
          setLoading(false);
          setCardStatus('normal');
          Toast.show({ content: '解挂成功', position: 'center' });
        }, 1500);
      }
    });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/profile')}
        className="bg-white"
      >
        卡片管理
      </NavBar>

      <div className="px-4 py-4">
        {/* Card Display */}
        <Card className="!rounded-xl !bg-gradient-to-br from-blue-500 to-blue-600 !text-white mb-4">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-white/20 rounded-full flex items-center justify-center">
                <CreditCardOutlined className="text-2xl" />
              </div>
              <div>
                <div className="font-medium">一卡通</div>
                <div className="text-xs text-blue-100">员工卡</div>
              </div>
            </div>
            <Tag color={cardStatus === 'normal' ? 'success' : 'danger'} fill="outline" className="!text-white !border-white/50">
              {cardStatus === 'normal' ? '正常' : '已挂失'}
            </Tag>
          </div>

          <div className="text-2xl font-mono tracking-widest mb-4">
            8888 8888 1234 5678
          </div>

          <div className="flex justify-between text-sm">
            <div>
              <div className="text-blue-100 text-xs">持卡人</div>
              <div>张三</div>
            </div>
            <div>
              <div className="text-blue-100 text-xs">有效期</div>
              <div>2028-09</div>
            </div>
          </div>
        </Card>

        {/* Card Info */}
        <Card className="!rounded-xl mb-4">
          <div className="text-sm font-medium text-gray-800 mb-4">卡片信息</div>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">卡号</span>
              <span>8888888812345678</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">开卡日期</span>
              <span>2024-09-01</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">账户余额</span>
              <span className="text-orange-500 font-medium">¥256.80</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">卡片状态</span>
              <span className={cardStatus === 'normal' ? 'text-green-500' : 'text-red-500'}>
                {cardStatus === 'normal' ? '正常' : '已挂失'}
              </span>
            </div>
          </div>
        </Card>

        {/* Actions */}
        <Card className="!rounded-xl">
          <div className="text-sm font-medium text-gray-800 mb-4">卡片操作</div>

          {cardStatus === 'normal' ? (
            <Button
              block
              color="danger"
              size="large"
              loading={loading}
              onClick={handleLock}
              className="!rounded-full"
            >
              <LockOutlined className="mr-2" />
              挂失卡片
            </Button>
          ) : (
            <Button
              block
              color="primary"
              size="large"
              loading={loading}
              onClick={handleUnlock}
              className="!rounded-full"
            >
              <UnlockOutlined className="mr-2" />
              解除挂失
            </Button>
          )}

          <div className="mt-4 p-3 bg-orange-50 rounded-lg">
            <div className="flex items-start gap-2">
              <ExclamationCircleOutlined className="text-orange-500 flex-shrink-0 mt-0.5" />
              <div className="text-xs text-orange-600">
                <div className="font-medium mb-1">温馨提示</div>
                <div>• 卡片丢失请立即挂失，避免资金损失</div>
                <div>• 挂失后付款码和实体卡均无法使用</div>
                <div>• 找回卡片后可自助解挂</div>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
