import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Form, Input, Button, TextArea, Picker, Toast, Card } from 'antd-mobile';
import { LeftOutlined, CustomerServiceOutlined } from '@ant-design/icons';

interface FeedbackType {
  label: string;
  value: string;
}

const feedbackTypes: FeedbackType[] = [
  { label: '消费问题', value: 'consumption' },
  { label: '门禁问题', value: 'access' },
  { label: '订餐问题', value: 'catering' },
  { label: '访客问题', value: 'visitor' },
  { label: '考勤问题', value: 'attendance' },
  { label: '其他问题', value: 'other' },
];

export default function Feedback(): JSX.Element {
  const [, setLocation] = useLocation();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState<boolean>(false);
  const [typeVisible, setTypeVisible] = useState<boolean>(false);

  const onSubmit = async (): Promise<void> => {
    try {
      const values = await form.validateFields();
      setLoading(true);

      setTimeout(() => {
        setLoading(false);
        Toast.show({ content: '提交成功，我们会尽快处理', position: 'center' });
        setLocation('/profile');
      }, 1500);
    } catch (error) {
      Toast.show({ content: '请完善信息', position: 'center' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/profile')}
        className="bg-white"
      >
        意见反馈
      </NavBar>

      <div className="px-4 py-4">
        <Card className="!rounded-xl">
          <div className="text-center mb-6">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CustomerServiceOutlined className="text-3xl text-blue-500" />
            </div>
            <div className="text-lg font-medium text-gray-800">意见反馈</div>
            <div className="text-sm text-gray-500 mt-2">您的建议是我们改进的动力</div>
          </div>

          <Form
            form={form}
            layout="horizontal"
            footer={
              <Button
                block
                color="primary"
                size="large"
                loading={loading}
                onClick={onSubmit}
                className="!rounded-full mt-4"
              >
                提交反馈
              </Button>
            }
          >
            <Form.Item
              name="type"
              label="反馈类型"
              rules={[{ required: true, message: '请选择反馈类型' }]}
              onClick={() => setTypeVisible(true)}
            >
              <Picker
                columns={[feedbackTypes]}
                visible={typeVisible}
                onClose={() => setTypeVisible(false)}
                onConfirm={(val: (string | null)[]) => {
                  form.setFieldValue('type', val[0]);
                }}
              >
                {(items: { label: string; value: string }[]) => (
                  <Input
                    placeholder="请选择反馈类型"
                    readOnly
                    value={items[0]?.label}
                  />
                )}
              </Picker>
            </Form.Item>

            <Form.Item
              name="content"
              label="问题描述"
              rules={[{ required: true, message: '请描述您遇到的问题' }]}
            >
              <TextArea
                placeholder="请详细描述您遇到的问题，以便我们更好地帮助您"
                rows={5}
                maxLength={500}
                showCount
              />
            </Form.Item>

            <Form.Item
              name="contact"
              label="联系方式"
              rules={[{ required: true, message: '请输入联系方式' }]}
            >
              <Input placeholder="请输入手机号或邮箱" />
            </Form.Item>
          </Form>
        </Card>

        {/* Contact Info */}
        <Card className="!rounded-xl mt-4">
          <div className="text-sm font-medium text-gray-800 mb-4">其他联系方式</div>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">客服电话</span>
              <span className="text-blue-500">400-888-8888</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">服务时间</span>
              <span>工作日 9:00-18:00</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">服务窗口</span>
              <span>行政楼一楼服务大厅</span>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
