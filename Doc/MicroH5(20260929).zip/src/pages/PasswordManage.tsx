import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Form, Input, Button, Toast, Card, Tabs } from 'antd-mobile';
import { LeftOutlined, LockOutlined } from '@ant-design/icons';

type TabType = 'change' | 'reset';

export default function PasswordManage(): JSX.Element {
  const [, setLocation] = useLocation();
  const [form] = Form.useForm();
  const [activeTab, setActiveTab] = useState<TabType>('change');
  const [loading, setLoading] = useState<boolean>(false);

  const onSubmit = async (): Promise<void> => {
    try {
      const values = await form.validateFields();

      if (activeTab === 'change') {
        if (values.newPassword !== values.confirmPassword) {
          Toast.show({ content: '两次输入的新密码不一致', position: 'center' });
          return;
        }
      }

      setLoading(true);
      setTimeout(() => {
        setLoading(false);
        Toast.show({ content: activeTab === 'change' ? '修改成功' : '重置成功', position: 'center' });
        setLocation('/profile');
      }, 1500);
    } catch (error) {
      Toast.show({ content: '请完善信息', position: 'center' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/profile')}
        className="bg-white"
      >
        密码管理
      </NavBar>

      <Tabs
        activeKey={activeTab}
        onChange={(key: string) => setActiveTab(key as TabType)}
        className="bg-white"
      >
        <Tabs.Tab title="修改密码" key="change" />
        <Tabs.Tab title="重置密码" key="reset" />
      </Tabs>

      <div className="px-4 py-4">
        <Card className="!rounded-xl">
          <div className="text-center mb-6">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <LockOutlined className="text-3xl text-blue-500" />
            </div>
            <div className="text-lg font-medium text-gray-800">
              {activeTab === 'change' ? '修改一卡通密码' : '重置一卡通密码'}
            </div>
          </div>

          <Form
            form={form}
            layout="horizontal"
            footer={
              <Button
                block
                color="primary"
                size="large"
                loading={loading}
                onClick={onSubmit}
                className="!rounded-full mt-4"
              >
                {activeTab === 'change' ? '确认修改' : '确认重置'}
              </Button>
            }
          >
            {activeTab === 'change' && (
              <>
                <Form.Item
                  name="oldPassword"
                  label="原密码"
                  rules={[{ required: true, message: '请输入原密码' }]}
                >
                  <Input placeholder="请输入原密码" type="password" />
                </Form.Item>

                <Form.Item
                  name="newPassword"
                  label="新密码"
                  rules={[
                    { required: true, message: '请输入新密码' },
                    { min: 6, message: '密码至少6位' }
                  ]}
                >
                  <Input placeholder="请输入新密码" type="password" />
                </Form.Item>

                <Form.Item
                  name="confirmPassword"
                  label="确认密码"
                  rules={[{ required: true, message: '请确认新密码' }]}
                >
                  <Input placeholder="请再次输入新密码" type="password" />
                </Form.Item>
              </>
            )}

            {activeTab === 'reset' && (
              <>
                <Form.Item
                  name="phone"
                  label="手机号"
                  rules={[
                    { required: true, message: '请输入手机号' },
                    { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号' }
                  ]}
                >
                  <Input placeholder="请输入绑定的手机号" type="tel" />
                </Form.Item>

                <Form.Item
                  name="verifyCode"
                  label="验证码"
                  rules={[{ required: true, message: '请输入验证码' }]}
                  extra={
                    <Button size="small" fill="outline">
                      获取验证码
                    </Button>
                  }
                >
                  <Input placeholder="请输入验证码" type="number" />
                </Form.Item>

                <Form.Item
                  name="idCard"
                  label="身份证号"
                  rules={[{ required: true, message: '请输入身份证号' }]}
                >
                  <Input placeholder="请输入身份证号" />
                </Form.Item>

                <Form.Item
                  name="newPassword"
                  label="新密码"
                  rules={[
                    { required: true, message: '请输入新密码' },
                    { min: 6, message: '密码至少6位' }
                  ]}
                >
                  <Input placeholder="请设置新密码" type="password" />
                </Form.Item>
              </>
            )}
          </Form>
        </Card>

        <div className="text-xs text-gray-400 mt-4 text-center">
          <div>密码用于消费验证和账户查询</div>
          <div className="mt-1">请妥善保管，避免泄露</div>
        </div>
      </div>
    </div>
  );
}
