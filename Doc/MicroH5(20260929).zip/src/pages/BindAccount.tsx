import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Form, Input, Button, Toast, Card } from 'antd-mobile';
import { LeftOutlined, UserOutlined } from '@ant-design/icons';

export default function BindAccount(): JSX.Element {
  const [, setLocation] = useLocation();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState<boolean>(false);
  const [countdown, setCountdown] = useState<number>(0);

  const sendVerifyCode = (): void => {
    if (countdown > 0) return;
    setCountdown(60);
    Toast.show({ content: '验证码已发送', position: 'center' });

    const timer = setInterval(() => {
      setCountdown((prev: number) => {
        if (prev <= 1) {
          clearInterval(timer);
          return 0;
        }
        return prev - 1;
      });
    }, 1000);
  };

  const onSubmit = async (): Promise<void> => {
    try {
      const values = await form.validateFields();
      setLoading(true);

      setTimeout(() => {
        setLoading(false);
        Toast.show({ content: '绑定成功', position: 'center' });
        setLocation('/');
      }, 1500);
    } catch (error) {
      Toast.show({ content: '请完善信息', position: 'center' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/profile')}
        className="bg-white"
      >
        账户绑定
      </NavBar>

      <div className="px-4 py-4">
        <Card className="!rounded-xl">
          <div className="text-center mb-6">
            <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <UserOutlined className="text-3xl text-blue-500" />
            </div>
            <div className="text-lg font-medium text-gray-800">绑定一脸通账户</div>
            <div className="text-sm text-gray-500 mt-2">请验证您的身份信息</div>
          </div>

          <Form
            form={form}
            layout="horizontal"
            footer={
              <Button
                block
                color="primary"
                size="large"
                loading={loading}
                onClick={onSubmit}
                className="!rounded-full mt-4"
              >
                确认绑定
              </Button>
            }
          >
            <Form.Item
              name="name"
              label="姓名"
              rules={[{ required: true, message: '请输入姓名' }]}
            >
              <Input placeholder="请输入姓名" />
            </Form.Item>

            <Form.Item
              name="employeeNo"
              label="工号"
              rules={[{ required: true, message: '请输入工号' }]}
            >
              <Input placeholder="请输入工号/学号" />
            </Form.Item>

            <Form.Item
              name="phone"
              label="手机号"
              rules={[
                { required: true, message: '请输入手机号' },
                { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号' }
              ]}
            >
              <Input placeholder="请输入手机号" type="tel" />
            </Form.Item>

            <Form.Item
              name="verifyCode"
              label="验证码"
              rules={[{ required: true, message: '请输入验证码' }]}
              extra={
                <Button
                  size="small"
                  fill="outline"
                  disabled={countdown > 0}
                  onClick={sendVerifyCode}
                >
                  {countdown > 0 ? `${countdown}s` : '获取验证码'}
                </Button>
              }
            >
              <Input placeholder="请输入验证码" type="number" />
            </Form.Item>

            <Form.Item
              name="password"
              label="查询密码"
              rules={[{ required: true, message: '请输入查询密码' }]}
            >
              <Input placeholder="请输入一卡通查询密码" type="password" />
            </Form.Item>
          </Form>
        </Card>

        <div className="text-xs text-gray-400 mt-4 text-center">
          <div>绑定后即可使用全部功能</div>
          <div className="mt-1">如有问题请联系管理员</div>
        </div>
      </div>
    </div>
  );
}
