import React from 'react';
import type { JSX } from 'react';
import { useLocation, Link } from 'wouter';

export default function NotFound(): JSX.Element {
  const [location] = useLocation();

  return (
    <div style={{
      display: 'flex',
      flexDirection: 'column',
      justifyContent: 'center',
      alignItems: 'center',
      minHeight: '100vh',
      background: '#fff',
      fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif',
      color: '#000',
      textAlign: 'center',
      position: 'relative',
      overflow: 'hidden',
    }}>
      {/* 中心放射渐变背景 */}
      <div style={{
        position: 'absolute',
        top: '50%',
        left: '50%',
        transform: 'translate(-50%, -50%)',
        width: '600px',
        height: '600px',
        borderRadius: '50%',
        background: 'radial-gradient(circle, rgba(59, 130, 246, 0.15) 0%, transparent 60%)',
        filter: 'blur(60px)',
        pointerEvents: 'none',
      }} />

      <div style={{ fontSize: '96px', fontWeight: '700', lineHeight: '1', position: 'relative', zIndex: 1 }}>404</div>
      <p style={{ fontSize: '18px', margin: '16px 0 0', color: '#666', position: 'relative', zIndex: 1 }}>页面未找到</p>
      <Link href="/" style={{
        display: 'inline-block',
        marginTop: '32px',
        padding: '12px 24px',
        background: '#3b82f6',
        color: '#fff',
        textDecoration: 'none',
        borderRadius: '6px',
        fontSize: '14px',
        position: 'relative',
        zIndex: 1,
      }}>
        返回首页
      </Link>
    </div>
  );
}
