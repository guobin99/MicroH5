import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Form, Input, Button, DatePicker, Picker, Toast, Card } from 'antd-mobile';
import { LeftOutlined } from '@ant-design/icons';
import dayjs from 'dayjs';

interface DeptItem {
  label: string;
  value: string;
}

const depts: DeptItem[] = [
  { label: '技术部', value: 'tech' },
  { label: '人事部', value: 'hr' },
  { label: '财务部', value: 'finance' },
  { label: '行政部', value: 'admin' },
  { label: '市场部', value: 'marketing' },
];

export default function VisitorAppointment(): JSX.Element {
  const [, setLocation] = useLocation();
  const [form] = Form.useForm();
  const [loading, setLoading] = useState<boolean>(false);
  const [visitDateVisible, setVisitDateVisible] = useState<boolean>(false);
  const [deptVisible, setDeptVisible] = useState<boolean>(false);

  const onSubmit = async (): Promise<void> => {
    try {
      const values = await form.validateFields();
      setLoading(true);

      // 模拟提交
      setTimeout(() => {
        setLoading(false);
        Toast.show({ content: '预约成功', position: 'center' });
        setLocation('/visitor-records');
      }, 1500);
    } catch (error) {
      Toast.show({ content: '请完善信息', position: 'center' });
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/')}
        className="bg-white"
      >
        访客预约
      </NavBar>

      <div className="px-4 py-4">
        <Card className="!rounded-xl">
          <Form
            form={form}
            layout="horizontal"
            footer={
              <Button
                block
                color="primary"
                size="large"
                loading={loading}
                onClick={onSubmit}
                className="!rounded-full mt-4"
              >
                提交预约
              </Button>
            }
          >
            <Form.Header>访客信息</Form.Header>

            <Form.Item
              name="name"
              label="访客姓名"
              rules={[{ required: true, message: '请输入访客姓名' }]}
            >
              <Input placeholder="请输入访客姓名" />
            </Form.Item>

            <Form.Item
              name="phone"
              label="手机号码"
              rules={[
                { required: true, message: '请输入手机号码' },
                { pattern: /^1[3-9]\d{9}$/, message: '请输入正确的手机号' }
              ]}
            >
              <Input placeholder="请输入手机号码" type="tel" />
            </Form.Item>

            <Form.Item
              name="idCard"
              label="身份证号"
              rules={[
                { required: true, message: '请输入身份证号' },
                { pattern: /^\d{17}[\dXx]$/, message: '请输入正确的身份证号' }
              ]}
            >
              <Input placeholder="请输入身份证号" />
            </Form.Item>

            <Form.Item
              name="company"
              label="来访单位"
            >
              <Input placeholder="请输入来访单位（选填）" />
            </Form.Item>

            <Form.Header>预约信息</Form.Header>

            <Form.Item
              name="dept"
              label="受访部门"
              rules={[{ required: true, message: '请选择受访部门' }]}
              onClick={() => setDeptVisible(true)}
            >
              <Picker
                columns={[depts]}
                visible={deptVisible}
                onClose={() => setDeptVisible(false)}
                onConfirm={(val: (string | null)[]) => {
                  form.setFieldValue('dept', val[0]);
                }}
              >
                {(items: { label: string; value: string }[]) => (
                  <Input
                    placeholder="请选择受访部门"
                    readOnly
                    value={items[0]?.label}
                  />
                )}
              </Picker>
            </Form.Item>

            <Form.Item
              name="visitDate"
              label="来访日期"
              rules={[{ required: true, message: '请选择来访日期' }]}
              onClick={() => setVisitDateVisible(true)}
            >
              <DatePicker
                visible={visitDateVisible}
                onClose={() => setVisitDateVisible(false)}
                min={new Date()}
                onConfirm={(val: Date) => {
                  form.setFieldValue('visitDate', dayjs(val).format('YYYY-MM-DD'));
                }}
              >
                {(value: Date | null) => (
                  <Input
                    placeholder="请选择来访日期"
                    readOnly
                    value={value ? dayjs(value).format('YYYY-MM-DD') : ''}
                  />
                )}
              </DatePicker>
            </Form.Item>

            <Form.Item
              name="visitTime"
              label="来访时段"
              rules={[{ required: true, message: '请输入来访时段' }]}
            >
              <Input placeholder="如：09:00-11:00" />
            </Form.Item>

            <Form.Item
              name="reason"
              label="来访事由"
              rules={[{ required: true, message: '请输入来访事由' }]}
            >
              <Input placeholder="请输入来访事由" />
            </Form.Item>

            <Form.Item
              name="count"
              label="随行人数"
            >
              <Input placeholder="请输入随行人数（选填）" type="number" />
            </Form.Item>

            <Form.Item
              name="plate"
              label="车牌号"
            >
              <Input placeholder="请输入车牌号（选填）" />
            </Form.Item>
          </Form>
        </Card>

        <div className="text-xs text-gray-400 mt-4 text-center">
          <div>提交后需等待审批，审批结果将通过消息推送</div>
          <div className="mt-1">访客需携带身份证原件，配合门禁核验</div>
        </div>
      </div>
    </div>
  );
}
