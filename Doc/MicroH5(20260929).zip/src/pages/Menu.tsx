﻿import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, Tabs, Tag, Button, Badge } from 'antd-mobile';
import { LeftOutlined, CoffeeOutlined, ShoppingCartOutlined } from '@ant-design/icons';

interface MenuItem {
  id: number;
  name: string;
  price: number;
  tag: string;
  image: string;
}

interface MenuData {
  [key: string]: MenuItem[];
}

const menuData: MenuData = {
  breakfast: [
    { id: 1, name: '豆浆', price: 2, tag: '饮品', image: '🥛' },
    { id: 2, name: '油条', price: 2, tag: '主食', image: '🥖' },
    { id: 3, name: '包子', price: 3, tag: '主食', image: '🥟' },
    { id: 4, name: '鸡蛋', price: 2, tag: '副食', image: '🥚' },
    { id: 5, name: '粥', price: 3, tag: '主食', image: '🥣' },
  ],
  lunch: [
    { id: 6, name: '红烧肉', price: 12, tag: '荤菜', image: '🥩' },
    { id: 7, name: '清蒸鱼', price: 15, tag: '荤菜', image: '🐟' },
    { id: 8, name: '宫保鸡丁', price: 10, tag: '荤菜', image: '🍗' },
    { id: 9, name: '番茄炒蛋', price: 8, tag: '半荤', image: '🍳' },
    { id: 10, name: '清炒时蔬', price: 6, tag: '素菜', image: '🥬' },
    { id: 11, name: '紫菜蛋花汤', price: 3, tag: '汤品', image: '🍲' },
    { id: 12, name: '米饭', price: 2, tag: '主食', image: '🍚' },
  ],
  dinner: [
    { id: 13, name: '糖醋排骨', price: 14, tag: '荤菜', image: '🍖' },
    { id: 14, name: '麻婆豆腐', price: 8, tag: '半荤', image: '🧈' },
    { id: 15, name: '凉拌黄瓜', price: 5, tag: '素菜', image: '🥒' },
    { id: 16, name: '冬瓜汤', price: 3, tag: '汤品', image: '🍲' },
    { id: 17, name: '馒头', price: 1, tag: '主食', image: '🥯' },
  ]
};

export default function Menu(): React.JSX.Element {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<string>('lunch');
  const [cart, setCart] = useState<MenuItem[]>([]);

  const addToCart = (item: MenuItem): void => {
    setCart([...cart, item]);
  };

  const getTotalPrice = (): number => {
    return cart.reduce((sum, item) => sum + item.price, 0);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/')}
        className="bg-white"
        right={<Badge content={cart.length}><ShoppingCartOutlined className="text-xl" /></Badge>}
      >
        今日菜谱
      </NavBar>

      {/* Date Selector */}
      <div className="bg-white px-4 py-3 flex items-center justify-between">
        <div className="text-sm text-gray-500">2026年9月12日 星期四</div>
        <Button size="mini" fill="outline">切换日期</Button>
      </div>

      {/* Meal Tabs */}
      <Tabs
        activeKey={activeTab}
        onChange={setActiveTab}
        className="bg-white"
      >
        <Tabs.Tab title="早餐" key="breakfast" />
        <Tabs.Tab title="午餐" key="lunch" />
        <Tabs.Tab title="晚餐" key="dinner" />
      </Tabs>

      {/* Menu List */}
      <div className="px-4 pb-24 mt-2">
        <div className="grid grid-cols-2 gap-3">
          {menuData[activeTab].map((item) => (
            <Card key={item.id} className="!rounded-xl !p-3">
              <div className="flex items-start gap-3">
                <div className="text-4xl">{item.image}</div>
                <div className="flex-1">
                  <div className="font-medium text-gray-800">{item.name}</div>
                  <Tag size="mini" color="default" className="!mt-1">{item.tag}</Tag>
                  <div className="flex items-center justify-between mt-2">
                    <div className="text-orange-500 font-medium">¥{item.price}</div>
                    <Button
                      size="mini"
                      color="primary"
                      onClick={() => addToCart(item)}
                    >
                      +
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>

      {/* Cart Bar */}
      {cart.length > 0 && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t px-4 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Badge content={cart.length}>
              <div className="w-10 h-10 bg-blue-500 rounded-full flex items-center justify-center text-white">
                <ShoppingCartOutlined />
              </div>
            </Badge>
            <div className="text-lg font-bold text-gray-800">¥{getTotalPrice()}</div>
          </div>
          <Button
            color="primary"
            onClick={() => setLocation('/order')}
          >
            去结算
          </Button>
        </div>
      )}
    </div>
  );
}
