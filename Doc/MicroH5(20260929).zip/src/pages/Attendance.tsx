import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, Button } from 'antd-mobile';
import { LeftOutlined, CheckCircleOutlined, ClockCircleOutlined } from '@ant-design/icons';
import dayjs from 'dayjs';
import type { Dayjs } from 'dayjs';

interface CalendarDay {
  date: number;
  dayOfWeek: number;
  status: 'normal' | 'late' | 'early' | 'absent' | 'leave' | 'rest' | 'future';
  checkIn: string | null;
  checkOut: string | null;
}

interface StatusMapItem {
  color: string;
  text: string;
}

// 生成当月日历数据
const generateCalendar = (): CalendarDay[] => {
  const days: CalendarDay[] = [];
  const today: Dayjs = dayjs();
  const startOfMonth: Dayjs = today.startOf('month');
  const daysInMonth: number = today.daysInMonth();

  for (let i = 1; i <= daysInMonth; i++) {
    const date: Dayjs = startOfMonth.date(i);
    const dayOfWeek: number = date.day();

    // 模拟考勤状态
    let status: CalendarDay['status'] = 'normal';
    if (i > today.date()) status = 'future';
    else if (dayOfWeek === 0 || dayOfWeek === 6) status = 'rest';
    else if ([5, 12, 19].includes(i)) status = 'late';
    else if ([8, 15].includes(i)) status = 'leave';

    days.push({
      date: i,
      dayOfWeek,
      status,
      checkIn: status === 'normal' ? '08:30' : null,
      checkOut: status === 'normal' ? '17:30' : null
    });
  }
  return days;
};

const statusMap: Record<string, StatusMapItem> = {
  normal: { color: 'bg-green-100 text-green-600', text: '正常' },
  late: { color: 'bg-orange-100 text-orange-600', text: '迟到' },
  early: { color: 'bg-yellow-100 text-yellow-600', text: '早退' },
  absent: { color: 'bg-red-100 text-red-600', text: '缺卡' },
  leave: { color: 'bg-blue-100 text-blue-600', text: '请假' },
  rest: { color: 'bg-gray-100 text-gray-500', text: '休息' },
  future: { color: 'bg-white text-gray-300', text: '' }
};

const weekDays: string[] = ['日', '一', '二', '三', '四', '五', '六'];

interface Stats {
  shouldWork: number;
  actualWork: number;
  late: number;
  early: number;
  absent: number;
  leave: number;
}

export default function Attendance(): JSX.Element {
  const [, setLocation] = useLocation();
  const [currentMonth] = useState<Dayjs>(dayjs());
  const calendarDays: CalendarDay[] = generateCalendar();

  const stats: Stats = {
    shouldWork: 22,
    actualWork: 20,
    late: 2,
    early: 0,
    absent: 0,
    leave: 2
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/')}
        className="bg-white"
        right={
          <Button size="small" onClick={() => setLocation('/attendance-apply')}>
            补签/请假
          </Button>
        }
      >
        我的考勤
      </NavBar>

      {/* Stats Cards */}
      <div className="px-4 py-4">
        <div className="grid grid-cols-3 gap-3 mb-4">
          <Card className="!rounded-xl !p-3">
            <div className="text-2xl font-bold text-gray-800">{stats.actualWork}</div>
            <div className="text-xs text-gray-500">实出勤</div>
          </Card>
          <Card className="!rounded-xl !p-3">
            <div className="text-2xl font-bold text-orange-500">{stats.late}</div>
            <div className="text-xs text-gray-500">迟到</div>
          </Card>
          <Card className="!rounded-xl !p-3">
            <div className="text-2xl font-bold text-blue-500">{stats.leave}</div>
            <div className="text-xs text-gray-500">请假</div>
          </Card>
        </div>

        {/* Calendar */}
        <Card className="!rounded-xl">
          <div className="text-center font-medium text-gray-800 mb-4">
            {currentMonth.format('YYYY年MM月')}
          </div>

          {/* Week Headers */}
          <div className="grid grid-cols-7 gap-1 mb-2">
            {weekDays.map((day: string) => (
              <div key={day} className="text-center text-xs text-gray-500 py-2">
                {day}
              </div>
            ))}
          </div>

          {/* Calendar Grid */}
          <div className="grid grid-cols-7 gap-1">
            {calendarDays.map((day: CalendarDay, index: number) => (
              <div
                key={index}
                className={`
                  aspect-square flex flex-col items-center justify-center rounded-lg text-sm
                  ${day.date === dayjs().date() ? 'ring-2 ring-blue-500' : ''}
                  ${statusMap[day.status].color}
                `}
              >
                <span className="font-medium">{day.date}</span>
                {day.status !== 'future' && day.status !== 'rest' && (
                  <span className="text-xs scale-75">{statusMap[day.status].text}</span>
                )}
              </div>
            ))}
          </div>

          {/* Legend */}
          <div className="flex flex-wrap gap-3 mt-4 pt-4 border-t">
            {Object.entries(statusMap).filter(([k]) => k !== 'future').map(([key, value]) => (
              <div key={key} className="flex items-center gap-1">
                <div className={`w-3 h-3 rounded ${value.color.split(' ')[0]}`} />
                <span className="text-xs text-gray-500">{value.text}</span>
              </div>
            ))}
          </div>
        </Card>

        {/* Today's Status */}
        <Card className="!rounded-xl mt-4">
          <div className="text-sm font-medium text-gray-800 mb-4">今日打卡</div>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center text-green-500">
                <CheckCircleOutlined className="text-xl" />
              </div>
              <div>
                <div className="font-medium text-gray-800">上班打卡</div>
                <div className="text-xs text-green-500">08:30 已打卡</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-gray-400">标准时间</div>
              <div className="text-sm text-gray-600">09:00</div>
            </div>
          </div>
          <div className="flex items-center justify-between mt-4 pt-4 border-t">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 bg-gray-100 rounded-full flex items-center justify-center text-gray-400">
                <ClockCircleOutlined className="text-xl" />
              </div>
              <div>
                <div className="font-medium text-gray-800">下班打卡</div>
                <div className="text-xs text-gray-400">未打卡</div>
              </div>
            </div>
            <div className="text-right">
              <div className="text-xs text-gray-400">标准时间</div>
              <div className="text-sm text-gray-600">18:00</div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
