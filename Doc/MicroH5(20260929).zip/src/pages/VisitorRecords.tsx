import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, Tabs, Tag, Button, Empty } from 'antd-mobile';
import { LeftOutlined, UserAddOutlined } from '@ant-design/icons';

interface VisitorRecord {
  id: number;
  visitorName: string;
  visitorPhone: string;
  visitDate: string;
  visitTime: string;
  dept: string;
  reason: string;
  status: 'approved' | 'pending' | 'rejected' | 'completed';
  statusText: string;
  applyTime: string;
}

const records: VisitorRecord[] = [
  {
    id: 1,
    visitorName: '李四',
    visitorPhone: '138****5678',
    visitDate: '2026-09-12',
    visitTime: '09:00-11:00',
    dept: '技术部',
    reason: '商务洽谈',
    status: 'approved',
    statusText: '已通过',
    applyTime: '2026-09-10 10:30'
  },
  {
    id: 2,
    visitorName: '王五',
    visitorPhone: '139****9012',
    visitDate: '2026-09-11',
    visitTime: '14:00-16:00',
    dept: '人事部',
    reason: '面试',
    status: 'pending',
    statusText: '审批中',
    applyTime: '2026-09-10 16:45'
  },
  {
    id: 3,
    visitorName: '赵六',
    visitorPhone: '137****3456',
    visitDate: '2026-09-10',
    visitTime: '10:00-12:00',
    dept: '行政部',
    reason: '设备维护',
    status: 'rejected',
    statusText: '已驳回',
    applyTime: '2026-09-09 09:15'
  },
  {
    id: 4,
    visitorName: '孙七',
    visitorPhone: '136****7890',
    visitDate: '2026-09-08',
    visitTime: '15:00-17:00',
    dept: '市场部',
    reason: '合作洽谈',
    status: 'completed',
    statusText: '已结束',
    applyTime: '2026-09-07 11:20'
  }
];

interface StatusMapItem {
  color: string;
  text: string;
}

const statusMap: Record<string, StatusMapItem> = {
  approved: { color: 'success', text: '已通过' },
  pending: { color: 'warning', text: '审批中' },
  rejected: { color: 'danger', text: '已驳回' },
  completed: { color: 'default', text: '已结束' }
};

export default function VisitorRecords(): JSX.Element {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<string>('all');

  const filteredRecords: VisitorRecord[] = activeTab === 'all'
    ? records
    : records.filter((r: VisitorRecord) => r.status === activeTab);

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/')}
        className="bg-white"
        right={
          <Button size="small" color="primary" onClick={() => setLocation('/visitor-appointment')}>
            + 预约
          </Button>
        }
      >
        访客记录
      </NavBar>

      {/* Tabs */}
      <Tabs
        activeKey={activeTab}
        onChange={setActiveTab}
        className="bg-white"
      >
        <Tabs.Tab title="全部" key="all" />
        <Tabs.Tab title="已通过" key="approved" />
        <Tabs.Tab title="审批中" key="pending" />
        <Tabs.Tab title="已驳回" key="rejected" />
      </Tabs>

      {/* Records List */}
      <div className="px-4 pb-20 mt-2">
        {filteredRecords.length > 0 ? (
          <div className="space-y-3">
            {filteredRecords.map((record: VisitorRecord) => (
              <Card key={record.id} className="!rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center text-blue-500">
                      <UserAddOutlined />
                    </div>
                    <div>
                      <div className="font-medium text-gray-800">{record.visitorName}</div>
                      <div className="text-xs text-gray-500">{record.visitorPhone}</div>
                    </div>
                  </div>
                  <Tag color={statusMap[record.status].color}>
                    {statusMap[record.status].text}
                  </Tag>
                </div>

                <div className="text-sm space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-500">来访日期</span>
                    <span>{record.visitDate}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">来访时段</span>
                    <span>{record.visitTime}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">受访部门</span>
                    <span>{record.dept}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">来访事由</span>
                    <span>{record.reason}</span>
                  </div>
                </div>

                {record.status === 'approved' && (
                  <div className="mt-4 pt-3 border-t flex gap-2">
                    <Button size="small" fill="outline" className="flex-1">
                      查看凭证
                    </Button>
                    <Button size="small" fill="outline" className="flex-1">
                      分享给访客
                    </Button>
                  </div>
                )}
              </Card>
            ))}
          </div>
        ) : (
          <Empty
            image={<UserAddOutlined className="text-6xl text-gray-300" />}
            description="暂无访客记录"
            className="mt-20"
          />
        )}
      </div>
    </div>
  );
}
