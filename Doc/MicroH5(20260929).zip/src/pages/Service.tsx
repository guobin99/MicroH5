import React from 'react';
import { useLocation } from 'wouter';
import { Card, List } from 'antd-mobile';
import {
  PayCircleOutlined,
  QrcodeOutlined,
  GatewayOutlined,
  CoffeeOutlined,
  UserAddOutlined,
  CalendarOutlined,
  CameraOutlined,
  CreditCardOutlined,
  FileTextOutlined,
  HistoryOutlined,
  RightOutlined
} from '@ant-design/icons';

interface ServiceItem {
  icon: React.ReactNode;
  text: string;
  color: string;
  path: string;
}

interface ServiceGroup {
  title: string;
  items: ServiceItem[];
}

const serviceGroups: ServiceGroup[] = [
  {
    title: '消费服务',
    items: [
      { icon: <PayCircleOutlined />, text: '账户充值', color: '#1677ff', path: '/recharge' },
      { icon: <QrcodeOutlined />, text: '付款码', color: '#52c41a', path: '/payment-code' },
      { icon: <HistoryOutlined />, text: '消费记录', color: '#722ed1', path: '/consumption-records' },
      { icon: <FileTextOutlined />, text: '充值记录', color: '#fa8c16', path: '/recharge-records' },
    ]
  },
  {
    title: '门禁服务',
    items: [
      { icon: <GatewayOutlined />, text: '通行二维码', color: '#13c2c2', path: '/pass-code' },
      { icon: <HistoryOutlined />, text: '通行记录', color: '#eb2f96', path: '/consumption-records' },
    ]
  },
  {
    title: '订餐服务',
    items: [
      { icon: <CoffeeOutlined />, text: '每日菜谱', color: '#fa8c16', path: '/menu' },
      { icon: <CoffeeOutlined />, text: '在线订餐', color: '#faad14', path: '/order' },
      { icon: <FileTextOutlined />, text: '我的订餐', color: '#d4b106', path: '/my-orders' },
    ]
  },
  {
    title: '访客服务',
    items: [
      { icon: <UserAddOutlined />, text: '访客预约', color: '#eb2f96', path: '/visitor-appointment' },
      { icon: <FileTextOutlined />, text: '访客记录', color: '#f5222d', path: '/visitor-records' },
    ]
  },
  {
    title: '考勤服务',
    items: [
      { icon: <CalendarOutlined />, text: '考勤记录', color: '#13c2c2', path: '/attendance' },
      { icon: <FileTextOutlined />, text: '补签/请假', color: '#1890ff', path: '/attendance-apply' },
    ]
  },
  {
    title: '其他服务',
    items: [
      { icon: <CameraOutlined />, text: '人脸采集', color: '#f5222d', path: '/face-collection' },
      { icon: <CreditCardOutlined />, text: '卡片管理', color: '#722ed1', path: '/card-manage' },
    ]
  }
];

export default function Service(): React.JSX.Element {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white px-4 py-4 sticky top-0 z-10">
        <div className="text-lg font-medium text-center">全部服务</div>
      </div>

      {/* Service Groups */}
      <div className="px-4 pb-20">
        {serviceGroups.map((group, groupIndex) => (
          <div key={groupIndex} className="mt-4">
            <div className="text-sm text-gray-500 mb-2 px-1">{group.title}</div>
            <Card className="!rounded-xl">
              <List>
                {group.items.map((item, itemIndex) => (
                  <List.Item
                    key={itemIndex}
                    prefix={
                      <div
                        className="w-8 h-8 rounded-lg flex items-center justify-center text-white"
                        style={{ backgroundColor: item.color }}
                      >
                        {item.icon}
                      </div>
                    }
                    arrow={<RightOutlined className="text-gray-400" />}
                    onClick={() => setLocation(item.path)}
                  >
                    {item.text}
                  </List.Item>
                ))}
              </List>
            </Card>
          </div>
        ))}
      </div>
    </div>
  );
}
