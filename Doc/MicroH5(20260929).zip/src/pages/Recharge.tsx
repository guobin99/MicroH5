﻿import React, { useState } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, Button, Input, Checkbox, Toast } from 'antd-mobile';
import { LeftOutlined, PayCircleOutlined } from '@ant-design/icons';

interface PresetAmount {
  value: number;
  label: string;
}

const presetAmounts: PresetAmount[] = [
  { value: 50, label: '50元' },
  { value: 100, label: '100元' },
  { value: 200, label: '200元' },
  { value: 500, label: '500元' }
];

export default function Recharge(): React.JSX.Element {
  const [, setLocation] = useLocation();
  const [selectedAmount, setSelectedAmount] = useState<number>(100);
  const [customAmount, setCustomAmount] = useState<string>('');
  const [agreed, setAgreed] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const finalAmount = customAmount ? parseFloat(customAmount) : selectedAmount;

  const handleRecharge = async (): Promise<void> => {
    if (!agreed) {
      Toast.show({ content: '请先同意充值协议', position: 'center' });
      return;
    }
    if (!finalAmount || finalAmount <= 0) {
      Toast.show({ content: '请输入充值金额', position: 'center' });
      return;
    }

    setLoading(true);
    // 模拟支付流程
    setTimeout(() => {
      setLoading(false);
      Toast.show({ content: '支付成功', position: 'center' });
      setLocation('/');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/')}
        className="bg-white"
      >
        账户充值
      </NavBar>

      <div className="px-4 py-4">
        {/* Balance Card */}
        <Card className="!rounded-xl mb-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center text-blue-500">
              <PayCircleOutlined className="text-xl" />
            </div>
            <div>
              <div className="text-sm text-gray-500">当前余额</div>
              <div className="text-2xl font-bold text-gray-800">¥256.80</div>
            </div>
          </div>
        </Card>

        {/* Amount Selection */}
        <Card className="!rounded-xl mb-4">
          <div className="text-sm font-medium text-gray-800 mb-4">选择充值金额</div>
          <div className="grid grid-cols-4 gap-3">
            {presetAmounts.map((item) => (
              <Button
                key={item.value}
                className={selectedAmount === item.value && !customAmount ? '!bg-blue-500 !text-white' : ''}
                onClick={() => {
                  setSelectedAmount(item.value);
                  setCustomAmount('');
                }}
              >
                {item.label}
              </Button>
            ))}
          </div>
          <div className="mt-4">
            <div className="text-sm text-gray-500 mb-2">自定义金额</div>
            <Input
              placeholder="请输入充值金额"
              type="number"
              value={customAmount}
              onChange={setCustomAmount}
              className="!text-lg"
            />
          </div>
        </Card>

        {/* Payment Method */}
        <Card className="!rounded-xl mb-4">
          <div className="text-sm font-medium text-gray-800 mb-4">支付方式</div>
          <div className="flex items-center gap-3 p-3 bg-green-50 rounded-lg">
            <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center text-white text-xs">
              微
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium">微信支付</div>
              <div className="text-xs text-gray-500">推荐使用</div>
            </div>
            <div className="w-5 h-5 rounded-full border-2 border-green-500 flex items-center justify-center">
              <div className="w-3 h-3 rounded-full bg-green-500" />
            </div>
          </div>
        </Card>

        {/* Agreement */}
        <div className="flex items-center gap-2 mb-4">
          <Checkbox checked={agreed} onChange={setAgreed} />
          <span className="text-xs text-gray-500">
            我已阅读并同意《充值服务协议》
          </span>
        </div>

        {/* Submit Button */}
        <Button
          block
          color="primary"
          size="large"
          loading={loading}
          onClick={handleRecharge}
          className="!rounded-full"
        >
          确认充值 {finalAmount > 0 ? `¥${finalAmount}` : ''}
        </Button>

        <div className="text-center text-xs text-gray-400 mt-4">
          <div>单笔限额 ¥5000 · 单日限额 ¥20000</div>
          <div className="mt-1">充值资金仅用于一脸通消费，不支持提现</div>
        </div>
      </div>
    </div>
  );
}
