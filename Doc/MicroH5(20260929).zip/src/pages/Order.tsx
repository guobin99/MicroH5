﻿import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, Button, Checkbox, Toast, Space } from 'antd-mobile';
import { LeftOutlined } from '@ant-design/icons';

interface MealType {
  value: string;
  label: string;
  time: string;
  price: number;
}

const mealTypes: MealType[] = [
  { value: 'breakfast', label: '早餐', time: '07:00-09:00', price: 10 },
  { value: 'lunch', label: '午餐', time: '11:30-13:30', price: 20 },
  { value: 'dinner', label: '晚餐', time: '17:30-19:30', price: 18 },
  { value: 'night', label: '夜宵', time: '21:00-23:00', price: 15 },
];

export default function Order(): JSX.Element {
  const [, setLocation] = useLocation();
  const [selectedMeals, setSelectedMeals] = useState<string[]>(['lunch']);
  const [selectedDates, setSelectedDates] = useState<string[]>(['2026-09-12']);
  const [agreed, setAgreed] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const toggleMeal = (value: string): void => {
    setSelectedMeals((prev: string[]) =>
      prev.includes(value)
        ? prev.filter((v: string) => v !== value)
        : [...prev, value]
    );
  };

  const calculateTotal = (): number => {
    return selectedMeals.reduce((sum: number, meal: string) => {
      const mealType = mealTypes.find((m: MealType) => m.value === meal);
      return sum + (mealType ? mealType.price * selectedDates.length : 0);
    }, 0);
  };

  const handleSubmit = async (): Promise<void> => {
    if (selectedMeals.length === 0) {
      Toast.show({ content: '请至少选择一个餐别', position: 'center' });
      return;
    }
    if (!agreed) {
      Toast.show({ content: '请同意订餐协议', position: 'center' });
      return;
    }

    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      Toast.show({ content: '订餐成功', position: 'center' });
      setLocation('/my-orders');
    }, 1500);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/menu')}
        className="bg-white"
      >
        确认订单
      </NavBar>

      <div className="px-4 py-4">
        {/* Date Selection */}
        <Card className="!rounded-xl mb-4">
          <div className="text-sm font-medium text-gray-800 mb-4">选择日期</div>
          <div className="flex gap-2 flex-wrap">
            {['2026-09-12', '2026-09-13', '2026-09-14'].map((date: string) => (
              <Button
                key={date}
                size="small"
                className={selectedDates.includes(date) ? '!bg-blue-500 !text-white' : ''}
                onClick={() => {
                  setSelectedDates((prev: string[]) =>
                    prev.includes(date)
                      ? prev.filter((d: string) => d !== date)
                      : [...prev, date]
                  );
                }}
              >
                {date.slice(5)}
              </Button>
            ))}
          </div>
        </Card>

        {/* Meal Selection */}
        <Card className="!rounded-xl mb-4">
          <div className="text-sm font-medium text-gray-800 mb-4">选择餐别</div>
          <Space direction="vertical" className="w-full" gap={12}>
            {mealTypes.map((meal: MealType) => (
              <div
                key={meal.value}
                className={`flex items-center justify-between p-3 rounded-lg border ${selectedMeals.includes(meal.value) ? 'border-blue-500 bg-blue-50' : 'border-gray-200'}`}
                onClick={() => toggleMeal(meal.value)}
              >
                <div className="flex items-center gap-3">
                  <Checkbox checked={selectedMeals.includes(meal.value)} />
                  <div>
                    <div className="font-medium text-gray-800">{meal.label}</div>
                    <div className="text-xs text-gray-500">{meal.time}</div>
                  </div>
                </div>
                <div className="text-orange-500 font-medium">¥{meal.price}</div>
              </div>
            ))}
          </Space>
        </Card>

        {/* Payment Method */}
        <Card className="!rounded-xl mb-4">
          <div className="text-sm font-medium text-gray-800 mb-4">支付方式</div>
          <div className="flex items-center gap-3 p-3 bg-blue-50 rounded-lg">
            <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs">
              卡
            </div>
            <div className="flex-1">
              <div className="text-sm font-medium">一卡通账户</div>
              <div className="text-xs text-gray-500">余额: ¥256.80</div>
            </div>
            <div className="w-5 h-5 rounded-full border-2 border-blue-500 flex items-center justify-center">
              <div className="w-3 h-3 rounded-full bg-blue-500" />
            </div>
          </div>
        </Card>

        {/* Order Summary */}
        <Card className="!rounded-xl mb-4">
          <div className="text-sm font-medium text-gray-800 mb-4">订单汇总</div>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-500">订餐日期</span>
              <span>{selectedDates.length}天</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-500">餐别数量</span>
              <span>{selectedMeals.length}餐</span>
            </div>
            <div className="flex justify-between pt-2 border-t">
              <span className="font-medium">合计金额</span>
              <span className="text-orange-500 font-bold text-lg">¥{calculateTotal()}</span>
            </div>
          </div>
        </Card>

        {/* Agreement */}
        <div className="flex items-center gap-2 mb-4">
          <Checkbox checked={agreed} onChange={setAgreed} />
          <span className="text-xs text-gray-500">
            我已阅读并同意《订餐服务协议》
          </span>
        </div>

        {/* Submit */}
        <Button
          block
          color="primary"
          size="large"
          loading={loading}
          onClick={handleSubmit}
          className="!rounded-full"
        >
          确认支付 ¥{calculateTotal()}
        </Button>
      </div>
    </div>
  );
}
