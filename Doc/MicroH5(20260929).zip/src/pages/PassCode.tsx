﻿import React, { useState, useEffect } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, Toast } from 'antd-mobile';
import { LeftOutlined, ReloadOutlined, GatewayOutlined, CheckCircleOutlined } from '@ant-design/icons';
import { QRCodeSVG } from 'qrcode.react';

interface UserInfo {
  name: string;
  dept: string;
  employeeNo: string;
}

export default function PassCode(): React.JSX.Element {
  const [, setLocation] = useLocation();
  const [qrValue, setQrValue] = useState<string>('');
  const [countdown, setCountdown] = useState<number>(60);
  const [userInfo] = useState<UserInfo>({
    name: '张三',
    dept: '技术部',
    employeeNo: '8888'
  });

  // 生成通行码
  const generateCode = (): void => {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substring(2, 10);
    const code = `PASS_${timestamp}_${random}_${userInfo.employeeNo}`;
    setQrValue(code);
    setCountdown(60);
  };

  // 初始化和倒计时
  useEffect(() => {
    generateCode();
    const timer = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          generateCode();
          return 60;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const handleRefresh = (): void => {
    generateCode();
    Toast.show({ content: '已刷新', position: 'center' });
  };

  return (
    <div className="min-h-screen bg-gray-100">
      <NavBar
        onBack={() => setLocation('/')}
        className="bg-white"
      >
        通行码
      </NavBar>

      <div className="px-4 py-4">
        {/* User Info Card */}
        <Card className="!rounded-xl mb-4">
          <div className="flex items-center gap-4">
            <div className="w-14 h-14 bg-purple-100 rounded-full flex items-center justify-center text-purple-500">
              <GatewayOutlined className="text-2xl" />
            </div>
            <div className="flex-1">
              <div className="text-lg font-medium text-gray-800">{userInfo.name}</div>
              <div className="text-sm text-gray-500">{userInfo.dept}</div>
              <div className="text-xs text-gray-400 mt-1">工号: {userInfo.employeeNo}</div>
            </div>
            <div className="flex items-center gap-1 text-green-500">
              <CheckCircleOutlined />
              <span className="text-sm">权限正常</span>
            </div>
          </div>
        </Card>

        {/* Pass Code Card */}
        <Card className="!rounded-xl !shadow-lg">
          <div className="flex flex-col items-center py-6">
            <div className="p-6 bg-white rounded-xl shadow-inner border-2 border-purple-100">
              <QRCodeSVG
                value={qrValue}
                size={220}
                level="H"
              />
            </div>

            <div className="text-center mt-6">
              <div className="text-lg font-medium text-gray-800">个人通行二维码</div>
              <div className="text-sm text-gray-500 mt-2">
                请在门禁设备前出示此二维码
              </div>
            </div>

            {/* Countdown */}
            <div className="flex items-center gap-2 mt-6 text-sm text-gray-500">
              <span>{countdown}秒后自动刷新</span>
              <ReloadOutlined
                className="cursor-pointer hover:text-purple-500"
                onClick={handleRefresh}
              />
            </div>
          </div>

          {/* Access Info */}
          <div className="bg-purple-50 rounded-lg p-4 mt-4">
            <div className="text-sm font-medium text-purple-800 mb-2">通行权限</div>
            <div className="text-xs text-purple-600 space-y-1">
              <div>• 办公区域: 已授权</div>
              <div>• 食堂区域: 已授权</div>
              <div>• 宿舍区域: 已授权</div>
            </div>
          </div>

          {/* Warning */}
          <div className="bg-orange-50 rounded-lg p-3 mt-4">
            <div className="text-xs text-orange-600">
              <div className="font-medium mb-1">使用提示：</div>
              <div>• 通行码每分钟自动刷新，请勿截图</div>
              <div>• 请在有效期内使用，超时请重新刷新</div>
              <div>• 仅限本人使用，转借他人将承担相应责任</div>
            </div>
          </div>
        </Card>

        {/* Recent Access Records */}
        <Card className="!rounded-xl mt-4">
          <div className="text-sm font-medium text-gray-800 mb-4">最近通行记录</div>
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-800">东门门禁</div>
                <div className="text-xs text-gray-400">08:30</div>
              </div>
              <div className="text-green-500 text-sm">已通过</div>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-800">办公楼大厅</div>
                <div className="text-xs text-gray-400">08:32</div>
              </div>
              <div className="text-green-500 text-sm">已通过</div>
            </div>
            <div className="flex items-center justify-between">
              <div>
                <div className="text-sm text-gray-800">食堂入口</div>
                <div className="text-xs text-gray-400">12:00</div>
              </div>
              <div className="text-green-500 text-sm">已通过</div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
