﻿import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, Button, Toast, Checkbox } from 'antd-mobile';
import { LeftOutlined, CameraOutlined, CheckCircleOutlined, InfoCircleOutlined } from '@ant-design/icons';

type StepType = 1 | 2 | 3;

export default function FaceCollection(): JSX.Element {
  const [, setLocation] = useLocation();
  const [step, setStep] = useState<StepType>(1); // 1:协议 2:拍照 3:完成
  const [agreed, setAgreed] = useState<boolean>(false);
  const [loading, setLoading] = useState<boolean>(false);

  const handleNext = (): void => {
    if (!agreed) {
      Toast.show({ content: '请先同意协议', position: 'center' });
      return;
    }
    setStep(2);
  };

  const handleCapture = (): void => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      setStep(3);
      Toast.show({ content: '采集成功', position: 'center' });
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/')}
        className="bg-white"
      >
        人脸采集
      </NavBar>

      {step === 1 && (
        <div className="px-4 py-4">
          <Card className="!rounded-xl">
            <div className="text-center mb-6">
              <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CameraOutlined className="text-3xl text-blue-500" />
              </div>
              <div className="text-lg font-medium text-gray-800">人脸信息授权</div>
              <div className="text-sm text-gray-500 mt-2">用于刷脸消费、门禁通行等场景</div>
            </div>

            <div className="bg-gray-50 rounded-lg p-4 mb-6">
              <div className="text-sm font-medium text-gray-800 mb-3">采集须知</div>
              <div className="text-xs text-gray-600 space-y-2">
                <div className="flex items-start gap-2">
                  <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs flex-shrink-0 mt-0.5">1</div>
                  <span>请确保光线充足，面部无遮挡</span>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs flex-shrink-0 mt-0.5">2</div>
                  <span>请正面面对摄像头，保持表情自然</span>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs flex-shrink-0 mt-0.5">3</div>
                  <span>请勿佩戴墨镜、口罩等遮挡物</span>
                </div>
                <div className="flex items-start gap-2">
                  <div className="w-4 h-4 bg-blue-500 rounded-full flex items-center justify-center text-white text-xs flex-shrink-0 mt-0.5">4</div>
                  <span>照片将加密存储，仅用于身份识别</span>
                </div>
              </div>
            </div>

            <div className="flex items-start gap-2 mb-6">
              <Checkbox checked={agreed} onChange={setAgreed} />
              <span className="text-xs text-gray-500">
                我已阅读并同意《人脸信息处理授权协议》，同意采集、使用我的人脸信息用于身份识别
              </span>
            </div>

            <Button
              block
              color="primary"
              size="large"
              onClick={handleNext}
              className="!rounded-full"
            >
              开始采集
            </Button>
          </Card>
        </div>
      )}

      {step === 2 && (
        <div className="px-4 py-4">
          <Card className="!rounded-xl">
            <div className="text-center mb-4">
              <div className="text-lg font-medium text-gray-800">请正对摄像头</div>
              <div className="text-sm text-gray-500 mt-1">将面部置于取景框内</div>
            </div>

            {/* Camera Preview Mock */}
            <div className="relative w-64 h-80 mx-auto bg-gray-800 rounded-2xl overflow-hidden mb-6">
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-white text-center">
                  <CameraOutlined className="text-4xl mb-2" />
                  <div className="text-sm">摄像头预览</div>
                </div>
              </div>
              {/* Face Frame */}
              <div className="absolute inset-8 border-2 border-dashed border-white/50 rounded-xl" />
              {/* Corner Markers */}
              <div className="absolute top-4 left-4 w-6 h-6 border-t-2 border-l-2 border-blue-500" />
              <div className="absolute top-4 right-4 w-6 h-6 border-t-2 border-r-2 border-blue-500" />
              <div className="absolute bottom-4 left-4 w-6 h-6 border-b-2 border-l-2 border-blue-500" />
              <div className="absolute bottom-4 right-4 w-6 h-6 border-b-2 border-r-2 border-blue-500" />
            </div>

            <div className="flex gap-3">
              <Button
                className="flex-1"
                fill="outline"
                onClick={() => setStep(1)}
              >
                取消
              </Button>
              <Button
                className="flex-1"
                color="primary"
                loading={loading}
                onClick={handleCapture}
              >
                拍照
              </Button>
            </div>
          </Card>
        </div>
      )}

      {step === 3 && (
        <div className="px-4 py-4">
          <Card className="!rounded-xl text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <CheckCircleOutlined className="text-3xl text-green-500" />
            </div>
            <div className="text-lg font-medium text-gray-800">采集成功</div>
            <div className="text-sm text-gray-500 mt-2">人脸照片已提交审核</div>

            <div className="bg-blue-50 rounded-lg p-4 mt-6 text-left">
              <div className="flex items-start gap-2">
                <InfoCircleOutlined className="text-blue-500 flex-shrink-0 mt-0.5" />
                <div className="text-xs text-blue-600">
                  <div className="font-medium mb-1">审核说明</div>
                  <div>• 审核结果将通过消息推送通知</div>
                  <div>• 审核通过后即可使用刷脸功能</div>
                  <div>• 如有问题请联系管理员</div>
                </div>
              </div>
            </div>

            <Button
              block
              color="primary"
              size="large"
              onClick={() => setLocation('/')}
              className="!rounded-full mt-6"
            >
              完成
            </Button>
          </Card>
        </div>
      )}
    </div>
  );
}
