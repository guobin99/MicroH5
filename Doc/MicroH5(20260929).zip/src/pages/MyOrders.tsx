﻿import React, { useState } from 'react';
import type { JSX } from 'react';
import { useLocation } from 'wouter';
import { NavBar, Card, Tabs, Tag, Button, Empty } from 'antd-mobile';
import { QRCodeSVG } from 'qrcode.react';
import { LeftOutlined, CoffeeOutlined } from '@ant-design/icons';

interface OrderItem {
  id: string;
  date: string;
  meal: string;
  items: string[];
  amount: number;
  status: 'ordered' | 'picked' | 'refunded' | 'expired';
  statusText: string;
  pickupCode: string;
  time: string;
}

const orders: OrderItem[] = [
  {
    id: 'O20260912001',
    date: '2026-09-12',
    meal: '午餐',
    items: ['红烧肉', '番茄炒蛋', '米饭'],
    amount: 22,
    status: 'ordered',
    statusText: '已预订',
    pickupCode: 'A123',
    time: '11:30-13:30'
  },
  {
    id: 'O20260911001',
    date: '2026-09-11',
    meal: '晚餐',
    items: ['糖醋排骨', '麻婆豆腐', '馒头'],
    amount: 23,
    status: 'picked',
    statusText: '已取餐',
    pickupCode: 'B456',
    time: '17:30-19:30'
  },
  {
    id: 'O20260910001',
    date: '2026-09-10',
    meal: '早餐',
    items: ['豆浆', '油条', '包子'],
    amount: 7,
    status: 'refunded',
    statusText: '已退订',
    pickupCode: 'C789',
    time: '07:00-09:00'
  }
];

interface StatusMapItem {
  color: string;
  text: string;
}

const statusMap: Record<string, StatusMapItem> = {
  ordered: { color: 'primary', text: '已预订' },
  picked: { color: 'success', text: '已取餐' },
  refunded: { color: 'danger', text: '已退订' },
  expired: { color: 'default', text: '已过期' }
};

export default function MyOrders(): JSX.Element {
  const [, setLocation] = useLocation();
  const [activeTab, setActiveTab] = useState<string>('all');
  const [showQR, setShowQR] = useState<string | null>(null);

  const filteredOrders: OrderItem[] = activeTab === 'all'
    ? orders
    : orders.filter((o: OrderItem) => o.status === activeTab);

  const handleCancel = (orderId: string): void => {
    // 处理退订逻辑
    console.log('Cancel order:', orderId);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <NavBar
        onBack={() => setLocation('/')}
        className="bg-white"
      >
        我的订餐
      </NavBar>

      {/* Tabs */}
      <Tabs
        activeKey={activeTab}
        onChange={setActiveTab}
        className="bg-white"
      >
        <Tabs.Tab title="全部" key="all" />
        <Tabs.Tab title="已预订" key="ordered" />
        <Tabs.Tab title="已取餐" key="picked" />
        <Tabs.Tab title="已退订" key="refunded" />
      </Tabs>

      {/* Orders List */}
      <div className="px-4 pb-20 mt-2">
        {filteredOrders.length > 0 ? (
          <div className="space-y-3">
            {filteredOrders.map((order: OrderItem) => (
              <Card key={order.id} className="!rounded-xl">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <CoffeeOutlined className="text-orange-500" />
                    <span className="font-medium">{order.meal}</span>
                    <span className="text-sm text-gray-500">{order.date}</span>
                  </div>
                  <Tag color={statusMap[order.status].color}>
                    {statusMap[order.status].text}
                  </Tag>
                </div>

                <div className="text-sm text-gray-600 mb-2">
                  {order.items.join('、')}
                </div>

                <div className="flex items-center justify-between text-xs text-gray-400 mb-3">
                  <span>取餐时间: {order.time}</span>
                  <span className="text-orange-500 font-medium">¥{order.amount}</span>
                </div>

                {order.status === 'ordered' && (
                  <div className="flex gap-2">
                    <Button
                      size="small"
                      fill="outline"
                      className="flex-1"
                      onClick={() => setShowQR(order.id)}
                    >
                      查看取餐码
                    </Button>
                    <Button
                      size="small"
                      fill="outline"
                      color="danger"
                      className="flex-1"
                      onClick={() => handleCancel(order.id)}
                    >
                      退订
                    </Button>
                  </div>
                )}

                {showQR === order.id && (
                  <div className="mt-4 pt-4 border-t flex flex-col items-center">
                    <div className="p-3 bg-white rounded-lg shadow-inner">
                      <QRCodeSVG value={order.pickupCode} size={150} />
                    </div>
                    <div className="text-lg font-mono mt-2">取餐码: {order.pickupCode}</div>
                    <div className="text-xs text-gray-500">请向工作人员出示此二维码</div>
                  </div>
                )}
              </Card>
            ))}
          </div>
        ) : (
          <Empty
            image={<CoffeeOutlined className="text-6xl text-gray-300" />}
            description="暂无订单"
            className="mt-20"
          />
        )}
      </div>
    </div>
  );
}
