import React from 'react';
import type { JSX } from 'react';
import { Route, Switch, Router } from 'wouter';
import { useHashLocation } from 'wouter/use-hash-location';
import { Toaster } from 'sonner';
import MainLayout from './layouts/MainLayout';
import Home from './pages/Home';
import Service from './pages/Service';
import Message from './pages/Message';
import Profile from './pages/Profile';
import Recharge from './pages/Recharge';
import PaymentCode from './pages/PaymentCode';
import PassCode from './pages/PassCode';
import ConsumptionRecords from './pages/ConsumptionRecords';
import RechargeRecords from './pages/RechargeRecords';
import Menu from './pages/Menu';
import Order from './pages/Order';
import MyOrders from './pages/MyOrders';
import VisitorAppointment from './pages/VisitorAppointment';
import VisitorRecords from './pages/VisitorRecords';
import Attendance from './pages/Attendance';
import AttendanceApply from './pages/AttendanceApply';
import FaceCollection from './pages/FaceCollection';
import BindAccount from './pages/BindAccount';
import CardManage from './pages/CardManage';
import PasswordManage from './pages/PasswordManage';
import Feedback from './pages/Feedback';
import NotFound from './pages/NotFound';

export default function App(): JSX.Element {
  return (
    <Router hook={useHashLocation}>
      <Switch>
        <Route path="/" component={MainLayout} />
        <Route path="/home" component={Home} />
        <Route path="/service" component={Service} />
        <Route path="/message" component={Message} />
        <Route path="/profile" component={Profile} />
        <Route path="/recharge" component={Recharge} />
        <Route path="/payment-code" component={PaymentCode} />
        <Route path="/pass-code" component={PassCode} />
        <Route path="/consumption-records" component={ConsumptionRecords} />
        <Route path="/recharge-records" component={RechargeRecords} />
        <Route path="/menu" component={Menu} />
        <Route path="/order" component={Order} />
        <Route path="/my-orders" component={MyOrders} />
        <Route path="/visitor-appointment" component={VisitorAppointment} />
        <Route path="/visitor-records" component={VisitorRecords} />
        <Route path="/attendance" component={Attendance} />
        <Route path="/attendance-apply" component={AttendanceApply} />
        <Route path="/face-collection" component={FaceCollection} />
        <Route path="/bind-account" component={BindAccount} />
        <Route path="/card-manage" component={CardManage} />
        <Route path="/password-manage" component={PasswordManage} />
        <Route path="/feedback" component={Feedback} />
        <Route component={NotFound} />
      </Switch>
      <Toaster />
    </Router>
  );
}
