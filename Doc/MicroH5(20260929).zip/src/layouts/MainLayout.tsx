import React, { useState } from 'react';
import { TabBar } from 'antd-mobile';
import { useLocation } from 'wouter';
import {
  HomeOutlined,
  AppstoreOutlined,
  MessageOutlined,
  UserOutlined
} from '@ant-design/icons';
import Home from '../pages/Home';
import Service from '../pages/Service';
import Message from '../pages/Message';
import Profile from '../pages/Profile';

interface Tab {
  key: string;
  title: string;
  icon: React.ReactNode;
}

const tabs: Tab[] = [
  { key: 'home', title: '首页', icon: <HomeOutlined /> },
  { key: 'service', title: '服务', icon: <AppstoreOutlined /> },
  { key: 'message', title: '消息', icon: <MessageOutlined /> },
  { key: 'profile', title: '我的', icon: <UserOutlined /> },
];

export default function MainLayout(): React.JSX.Element {
  const [activeKey, setActiveKey] = useState<string>('home');
  const [, setLocation] = useLocation();

  const handleTabChange = (key: string): void => {
    setActiveKey(key);
    setLocation(`/${key}`);
  };

  return (
    <div className="flex flex-col h-screen bg-gray-50">
      <div className="flex-1 overflow-auto">
        {activeKey === 'home' && <Home />}
        {activeKey === 'service' && <Service />}
        {activeKey === 'message' && <Message />}
        {activeKey === 'profile' && <Profile />}
      </div>
      <TabBar activeKey={activeKey} onChange={handleTabChange} className="bg-white border-t">
        {tabs.map(item => (
          <TabBar.Item key={item.key} icon={item.icon} title={item.title} />
        ))}
      </TabBar>
    </div>
  );
}
