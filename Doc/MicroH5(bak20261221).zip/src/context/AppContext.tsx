import React, { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { getToken, setToken, m as api } from '../lib/api';
import { mapMealOrder } from '../lib/orderMap';
import {
  AccountInfo,
  AccountStatus,
  AttendanceApplication,
  FaceStatus,
  MealOrder,
  MessageItem,
  MessageType,
  RechargeRecord,
  UserProfile,
  VisitorRecord,
  defaultNotificationSettings,
  initialAccount,
  initialAttendanceApplications,
  initialMessages,
  initialRechargeRecords,
  initialUser,
  initialVisitorRecords,
} from '../data/mock';

interface BindPayload {
  name: string;
  employeeNo: string;
  phone: string;
  password?: string;
  verifyCode?: string;
}

interface AppContextValue {
  isBound: boolean;
  user: UserProfile;
  account: AccountInfo;
  faceStatus: FaceStatus;
  faceRejectReason: string;
  messages: MessageItem[];
  notificationSettings: Record<MessageType, boolean>;
  rechargeRecords: RechargeRecord[];
  mealOrders: MealOrder[];
  visitorRecords: VisitorRecord[];
  attendanceApplications: AttendanceApplication[];
  unreadCount: number;
  bindAccount: (payload: BindPayload) => Promise<void>;
  unbindAccount: () => Promise<void>;
  updatePhone: (phone: string, code?: string) => Promise<void>;
  setAccountStatus: (status: AccountStatus) => void;
  recharge: (amount: number) => Promise<RechargeRecord>;
  deduct: (amount: number) => boolean;
  refund: (amount: number) => void;
  setFaceReviewing: () => void;
  setFaceResult: (approved: boolean, reason?: string) => void;
  markMessageRead: (id: string) => void;
  markAllMessagesRead: () => void;
  toggleNotification: (type: MessageType) => void;
  addMealOrder: (order: MealOrder) => void;
  cancelMealOrder: (order: MealOrder) => Promise<void>;
  addVisitorRecord: (record: VisitorRecord) => Promise<void>;
  approveVisitor: (id: string) => Promise<void>;
  rejectVisitor: (id: string, reason: string) => Promise<void>;
  signOutVisitor: (id: string) => Promise<void>;
  addAttendanceApplication: (application: AttendanceApplication) => Promise<void>;
  refreshProfile: () => Promise<void>;
  refreshRechargeRecords: () => Promise<void>;
  refreshMealOrders: (bgn?: string, end?: string) => Promise<void>;
  refreshAttendanceApplications: () => Promise<void>;
  refreshVisitorRecords: () => Promise<void>;
  refreshMessages: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | undefined>(undefined);

function readStorage<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    if (!raw) return fallback;
    const parsed = JSON.parse(raw) as T;
    if (Array.isArray(fallback) || typeof fallback !== 'object' || fallback === null) return parsed;
    return { ...fallback, ...(parsed as Record<string, unknown>) } as T;
  } catch {
    return fallback;
  }
}

function writeStorage<T>(key: string, value: T): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(key, JSON.stringify(value));
  } catch {
    // 存储不可用时保持内存状态
  }
}

function nowText(): string {
  const pad = (value: number): string => String(value).padStart(2, '0');
  const date = new Date();
  return `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())} ${pad(date.getHours())}:${pad(date.getMinutes())}`;
}

export function AppProvider({ children }: { children: React.ReactNode }): React.JSX.Element {
  // 对接后端：以 JWT Token 作为绑定/登录态（附加5）
  const [isBound, setIsBound] = useState<boolean>(() => !!getToken());
  const [user, setUser] = useState<UserProfile>(() => readStorage('ylt-user', initialUser));
  const [account, setAccount] = useState<AccountInfo>(() => readStorage('ylt-account', initialAccount));
  const [faceStatus, setFaceStatus] = useState<FaceStatus>(() =>
    (typeof window !== 'undefined' && (window.localStorage.getItem('ylt-face-status') as FaceStatus)) || 'approved',
  );
  const [faceRejectReason, setFaceRejectReason] = useState<string>(() =>
    typeof window !== 'undefined' ? window.localStorage.getItem('ylt-face-reason') || '' : '',
  );
  const [messages, setMessages] = useState<MessageItem[]>(() => readStorage('ylt-messages', initialMessages));
  const [notificationSettings, setNotificationSettings] = useState<Record<MessageType, boolean>>(() =>
    readStorage('ylt-notification-settings', defaultNotificationSettings),
  );
  const [rechargeRecords, setRechargeRecords] = useState<RechargeRecord[]>(initialRechargeRecords);
  const [mealOrders, setMealOrders] = useState<MealOrder[]>([]);
  const [visitorRecords, setVisitorRecords] = useState<VisitorRecord[]>(() =>
    readStorage('ylt-visitor-records', initialVisitorRecords),
  );
  const [attendanceApplications, setAttendanceApplications] = useState<AttendanceApplication[]>(initialAttendanceApplications);

  const updateUser = useCallback((next: UserProfile) => {
    setUser(next);
    writeStorage('ylt-user', next);
  }, []);

  const updateAccount = useCallback((next: AccountInfo) => {
    setAccount(next);
    writeStorage('ylt-account', next);
  }, []);

  const updateMessages = useCallback((next: MessageItem[]) => {
    setMessages(next);
    writeStorage('ylt-messages', next);
  }, []);

  const updateRechargeRecords = useCallback((next: RechargeRecord[]) => {
    setRechargeRecords(next);
  }, []);

  const updateMealOrders = useCallback((next: MealOrder[]) => {
    setMealOrders(next);
  }, []);

  const updateVisitorRecords = useCallback((next: VisitorRecord[]) => {
    setVisitorRecords(next);
    writeStorage('ylt-visitor-records', next);
  }, []);

  const updateAttendanceApplications = useCallback((next: AttendanceApplication[]) => {
    setAttendanceApplications(next);
  }, []);

  // ---------- 后端数据同步 ----------
  const refreshProfile = useCallback(async (): Promise<void> => {
    try {
      const p = await api.profile();
      if (!p || p.personId === undefined) return;
      updateUser({
        name: p.name || '',
        // 部门名称取后台 ST_Department.Dept_Name；职称取 ST_Person.Title（均由 /m/auth/profile 返回）
        department: p.department || user.department,
        title: p.title || '',
        employeeNo: p.personNo || '',
        phone: (p.mobile || '').replace(/^(\d{3})\d{4}(\d{4})$/, '$1****$2'),
        idCard: p.idNumber || '',
      });
      updateAccount({
        balance: Number(p.balance || 0),
        pendingAmount: account.pendingAmount,
        cardNo: p.cardNo || '',
        status: (p.cardState === 0 || p.cardState === undefined) ? 'normal' : 'frozen',
        updatedAt: (p.updateTime as string) || account.updatedAt,
      });
    } catch {
      // 后端不可用时保留本地缓存
    }
  }, [account.pendingAmount, updateAccount, updateUser, user.department, user.title]);

  const refreshRechargeRecords = useCallback(async (bgn = '', end = ''): Promise<void> => {
    try {
      const rows = await api.rechargeRecords(bgn, end);
      if (!Array.isArray(rows)) return;
      updateRechargeRecords(rows.map((r: any) => ({
        id: String(r.id),
        amount: Number(r.amount),
        // 渠道由后台按 Out_Trade_No 判定：非空=微信充值，空=刷卡充值
        channel: r.channel || '其他充值',
        status: 'paid' as const,
        time: (r.time || '').replace('T', ' ').substring(0, 16),
        orderNo: r.outTradeNo || '-',
        merchantNo: r.outTradeNo || '',
        progress: r.remark || '支付成功，平台已入账',
        beforeFund: Number(r.beforeFund || 0),
        balance: Number(r.balance || 0),
      })));
    } catch { /* 忽略 */ }
  }, [updateRechargeRecords]);

  const refreshMealOrders = useCallback(async (bgn = '', end = ''): Promise<void> => {
    try {
      const rows = await api.myOrders(bgn, end);
      // 仅以后台数据为准；返回异常时清空，避免保留上一次的陈旧数据
      if (!Array.isArray(rows)) { updateMealOrders([]); return; }
      updateMealOrders(rows.map(mapMealOrder));
    } catch {
      // 请求失败同样清空，不保留演示/陈旧订单
      updateMealOrders([]);
    }
  }, [updateMealOrders]);

  const refreshAttendanceApplications = useCallback(async (): Promise<void> => {
    // 合并三类申请：请假(KQ_Leave) + 补签(KQ_FillAttend) + 申诉(WX_KQ_Appeal)
    const [leaves, others] = await Promise.all([
      api.leaveList().catch(() => []),
      api.attapplyList().catch(() => []),
    ]);
    const list: AttendanceApplication[] = [];
    if (Array.isArray(leaves)) {
      leaves.forEach((l: any) => list.push({
        id: String(l.id),
        type: '请假' as const,
        title: `请假（${l.kind || ''}）`,
        dateRange: `${l.timeBgn || ''} ~ ${l.timeEnd || ''}`,
        reason: l.remark || '',
        status: 'pending' as const,
        submitTime: (l.date || '') + ' ' + (l.timeBgn || '').substring(11, 16),
      }));
    }
    if (Array.isArray(others)) {
      others.forEach((o: any) => list.push({
        id: String(o.id),
        type: (o.type === '补签' ? '补签' : '申诉') as '补签' | '申诉',
        title: o.title || o.type,
        dateRange: o.dateRange || '',
        reason: o.reason || '',
        status: (o.status === 'approved' ? 'approved' : o.status === 'rejected' ? 'rejected' : 'pending') as 'pending' | 'approved' | 'rejected',
        submitTime: o.submitTime || '',
      }));
    }
    list.sort((x, y) => (x.submitTime < y.submitTime ? 1 : -1));
    updateAttendanceApplications(list);
  }, [updateAttendanceApplications]);

  const refreshVisitorRecords = useCallback(async (): Promise<void> => {
    try {
      const rows = await api.visitorList();
      if (!Array.isArray(rows)) return;
      updateVisitorRecords(rows.map((v: any) => ({
        id: String(v.id),
        visitorName: v.visitorName || '',
        visitorPhone: v.visitorPhone || '',
        idCard: v.idCard || '',
        company: v.company || '',
        department: '',
        reason: v.reason || '',
        visitDate: v.visitDate || '',
        visitTime: v.visitTime || '',
        companions: Number(v.companions || 0),
        plate: v.plate || '',
        status: v.status || 'pending',
        applyTime: v.applyTime || '',
        passCode: v.passCode || '',
        rejectReason: v.rejectReason || '',
        signOutTime: v.signOutTime || '',
      })));
    } catch { /* 忽略 */ }
  }, [updateVisitorRecords]);

  const refreshMessages = useCallback(async (): Promise<void> => {
    try {
      const rows = await api.messageList();
      if (!Array.isArray(rows)) return;
      updateMessages(rows.map((x: any) => ({
        id: String(x.id),
        type: (x.type || 'system') as MessageType,
        title: x.title || '',
        content: x.content || '',
        time: x.time || '',
        read: !!x.read,
      })));
    } catch { /* 忽略 */ }
  }, [updateMessages]);

  useEffect(() => {
    if (!getToken()) return;
    refreshProfile();
    refreshRechargeRecords();
    refreshMealOrders();
    refreshAttendanceApplications();
    refreshVisitorRecords();
    refreshMessages();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

// ---------- 绑定 / 解绑（附加7：更新 ST_Person.OpenID，支持解绑） ----------
const bindAccount = useCallback(async (payload: BindPayload): Promise<void> => {
    const wxOpenId = sessionStorage.getItem('ylt-wx-openid') || '';
    const wxUnionId = sessionStorage.getItem('ylt-wx-unionid') || '';
    const wxCode = (typeof window !== 'undefined' && sessionStorage.getItem('ylt-wx-code')) || '';
    let res = await api.bind({
        PersonNo: payload.employeeNo,
        Password: payload.password || '',
        Mobile: payload.phone,
        SmsCode: payload.verifyCode || '',
        OpenId: wxOpenId,      // 改为传 OpenId
        UnionId: wxUnionId,
        Code: wxCode,
      });
     
    if (!res.success && res.msg && res.msg.indexOf('微信身份获取失败') >= 0) {
       if (payload.password)
        res = await api.login(payload.employeeNo, payload.password);
      else res = await api.smsLogin(payload.phone, payload.verifyCode || '');
    }
    
    if (!res || !res.success) throw new Error((res && res.msg) || '绑定失败');

    setToken(res.access_token || '');
    setIsBound(true);
    writeStorage('ylt-bound', true);
    if (res.user) {
      updateUser({
        ...user,
        name: res.user.name || payload.name || user.name,
        employeeNo: res.user.personNo || payload.employeeNo,
      });
    }
    // 绑定成功后清除微信临时凭证
    sessionStorage.removeItem('ylt-wx-openid');
    sessionStorage.removeItem('ylt-wx-unionid');
    sessionStorage.removeItem('ylt-wx-code');
    await refreshProfile();
    await refreshRechargeRecords();
  }, [refreshProfile, refreshRechargeRecords, updateUser, user]);

  const unbindAccount = useCallback(async (): Promise<void> => {
    try {
      await api.unbind();
    } catch {
      // 后端不可达也允许本地解绑
    }
    setToken('');
    setIsBound(false);
    if (typeof window !== 'undefined') {
      window.localStorage.removeItem('ylt-bound');
      window.localStorage.removeItem('ylt-user');
      window.localStorage.removeItem('ylt-account');
    }
    setUser(initialUser);
    setAccount(initialAccount);
  }, []);

  const updatePhone = useCallback(async (phone: string, code?: string): Promise<void> => {
    if (code) {
      const res = await api.changePhone(phone, code);
      if (!res.success) throw new Error(res.msg || '手机号修改失败');
    }
    const next = { ...user, phone };
    updateUser(next);
  }, [updateUser, user]);

  const setAccountStatus = useCallback((status: AccountStatus) => {
    const next = { ...account, status };
    updateAccount(next);
  }, [account, updateAccount]);

  // ---------- 充值（附加1：真实微信支付 JSAPI → 异步通知 → 查询兜底） ----------
  const recharge = useCallback(async (amount: number): Promise<RechargeRecord> => {
    const created = await api.rechargeCreate(amount);
    if (!created.success) throw new Error(created.msg || '创建支付订单失败');

    const record: RechargeRecord = {
      id: created.outTradeNo,
      amount,
      channel: '微信支付',
      status: 'pending',
      time: nowText(),
      orderNo: created.outTradeNo,
      merchantNo: '',
      progress: '已下单，等待支付',
      beforeFund: 0,
      balance: 0,
    };
    updateRechargeRecords([record, ...rechargeRecords]);

    // 微信内调起支付（服务号 JSAPI）
    if (typeof window !== 'undefined' && window.WeixinJSBridge && created.payParams) {
      await new Promise<void>((resolve, reject) => {
        window.WeixinJSBridge.invoke('getBrandWCPayRequest', created.payParams, (payRes: any) => {
          if (payRes && (payRes.err_msg === 'get_brand_wcpay_request:ok')) resolve();
          else reject(new Error('支付未完成或已取消'));
        });
      });
    }

    // 查询兜底：轮询直至微信侧成功（异步通知可能先于/晚于查询到达）
    let finalState = 'NOTPAY';
    for (let i = 0; i < 6; i += 1) {
      await new Promise((r) => window.setTimeout(r, 2000));
      const q = await api.rechargeQuery(created.outTradeNo);
      finalState = q.tradeState;
      if (q.tradeState === 'SUCCESS') break;
      if (q.tradeState === 'CLOSED') break;
    }
    if (finalState !== 'SUCCESS') throw new Error('支付结果未知，请在充值记录中确认');

    const paidRecord: RechargeRecord = { ...record, status: 'paid', progress: '支付成功，平台已入账' };
    updateRechargeRecords([paidRecord, ...rechargeRecords.filter((r) => r.id !== record.id)]);
    await refreshProfile();
    return paidRecord;
  }, [rechargeRecords, refreshProfile, updateRechargeRecords]);

  const deduct = useCallback((amount: number): boolean => {
    if (account.balance < amount || account.status !== 'normal') return false;
    const next = {
      ...account,
      balance: Number((account.balance - amount).toFixed(2)),
      updatedAt: nowText(),
    };
    updateAccount(next);
    return true;
  }, [account, updateAccount]);

  const refund = useCallback((amount: number) => {
    const next = {
      ...account,
      balance: Number((account.balance + amount).toFixed(2)),
      updatedAt: nowText(),
    };
    updateAccount(next);
  }, [account, updateAccount]);

  const setFaceReviewing = useCallback(() => {
    setFaceStatus('reviewing');
    if (typeof window !== 'undefined') window.localStorage.setItem('ylt-face-status', 'reviewing');
  }, []);

  const setFaceResult = useCallback((approved: boolean, reason?: string) => {
    const nextStatus: FaceStatus = approved ? 'approved' : 'rejected';
    const nextReason = approved ? '' : reason || '照片不符合要求';
    setFaceStatus(nextStatus);
    setFaceRejectReason(nextReason);
    if (typeof window !== 'undefined') {
      window.localStorage.setItem('ylt-face-status', nextStatus);
      window.localStorage.setItem('ylt-face-reason', nextReason);
    }
  }, []);

  const markMessageRead = useCallback((id: string) => {
    updateMessages(messages.map((item) => (item.id === id ? { ...item, read: true } : item)));
    api.messageRead(id).then(() => refreshMessages()).catch(() => {});
  }, [messages, refreshMessages, updateMessages]);

  const markAllMessagesRead = useCallback(() => {
    updateMessages(messages.map((item) => ({ ...item, read: true })));
    api.messageReadAll().then(() => refreshMessages()).catch(() => {});
  }, [messages, refreshMessages, updateMessages]);

  const toggleNotification = useCallback((type: MessageType) => {
    const next = { ...notificationSettings, [type]: !notificationSettings[type] };
    setNotificationSettings(next);
    writeStorage('ylt-notification-settings', next);
  }, [notificationSettings]);

  const addMealOrder = useCallback((order: MealOrder) => {
    updateMealOrders([order, ...mealOrders]);
  }, [mealOrders, updateMealOrders]);

  const cancelMealOrder = useCallback(async (order: MealOrder): Promise<void> => {
    if (!order || order.status !== 'ordered') return;
    const res = await api.cancelOrder(order.orderNo);
    if (!res.success) throw new Error(res.msg || '取消失败');
    // 消费扣款模式（DC.Solution=0）订餐时未扣钱，退订只取消订单、不退款，
    // 状态记为 cancelled 而非 refunded，避免界面出现"退款已退回余额"的假象
    const wasRefunded = res.refunded !== false && order.mode !== '消费扣款';
    // 全局列表仅作订餐页「重复订餐」校验用，命中才同步更新
    updateMealOrders(mealOrders.map((item) => (item.id === order.id
      ? { ...item, status: wasRefunded ? 'refunded' : 'cancelled' }
      : item)));
    if (wasRefunded) refund(order.amount);
    await refreshProfile();
  }, [mealOrders, refund, refreshProfile, updateMealOrders]);

  // ---------- 访客预约（对接后端 VisitorApply） ----------
  const addVisitorRecord = useCallback(async (record: VisitorRecord): Promise<void> => {
    updateVisitorRecords([record, ...visitorRecords]);
    try {
      const res = await api.visitorSubmit({
        visitorName: record.visitorName,
        visitorPhone: record.visitorPhone,
        idCard: record.idCard,
        company: record.company,
        reason: record.reason,
        visitDate: record.visitDate,
        visitTime: record.visitTime,
        companions: record.companions,
        plate: record.plate,
      });
      if (res.success) await refreshVisitorRecords();
    } catch { /* 离线时保留本地记录 */ }
  }, [refreshVisitorRecords, updateVisitorRecords, visitorRecords]);

  const approveVisitor = useCallback(async (id: string): Promise<void> => {
    try {
      const res = await api.visitorApprove(id);
      if (res.success) { await refreshVisitorRecords(); return; }
    } catch { /* 回退本地 */ }
    updateVisitorRecords(visitorRecords.map((item) => (
      item.id === id ? { ...item, status: 'approved', passCode: `VIS-${Math.random().toString(36).slice(2, 8).toUpperCase()}` } : item
    )));
  }, [refreshVisitorRecords, updateVisitorRecords, visitorRecords]);

  const rejectVisitor = useCallback(async (id: string, reason: string): Promise<void> => {
    try {
      const res = await api.visitorReject(id, reason);
      if (res.success) { await refreshVisitorRecords(); return; }
    } catch { /* 回退本地 */ }
    updateVisitorRecords(visitorRecords.map((item) => (
      item.id === id ? { ...item, status: 'rejected', rejectReason: reason } : item
    )));
  }, [refreshVisitorRecords, updateVisitorRecords, visitorRecords]);

  const signOutVisitor = useCallback(async (id: string): Promise<void> => {
    try {
      const res = await api.visitorSignOut(id);
      if (res.success) { await refreshVisitorRecords(); return; }
    } catch { /* 回退本地 */ }
    updateVisitorRecords(visitorRecords.map((item) => (
      item.id === id ? { ...item, status: 'completed', signOutTime: nowText() } : item
    )));
  }, [refreshVisitorRecords, updateVisitorRecords, visitorRecords]);

  // 考勤申请统一入口：按类型分发到 请假/补签/申诉 后端接口（乐观更新 + 成功后刷新）
  const addAttendanceApplication = useCallback(async (application: AttendanceApplication): Promise<void> => {
    updateAttendanceApplications([application, ...attendanceApplications]);
    try {
      let ok = true;
      if (application.type === '请假') {
        const res = await api.leaveSubmit({ kindNo: application.title, timeBgn: '', timeEnd: '', remark: application.reason });
        ok = res.success;
      } else if (application.type === '补签') {
        const parts = (application.dateRange || '').split(' ');
        const res = await api.attapplyResign({
          date: parts[0] || application.dateRange,
          time: parts[1] || '08:30',
          clockType: application.title.indexOf('下班') >= 0 ? '下班' : '上班',
          reason: application.reason,
        });
        ok = res.success;
      } else {
        const res = await api.attapplyAppeal({
          date: application.dateRange,
          appealType: application.title,
          reason: application.reason,
        });
        ok = res.success;
      }
      if (ok) await refreshAttendanceApplications();
    } catch { /* 离线时保留本地记录 */ }
  }, [attendanceApplications, refreshAttendanceApplications, updateAttendanceApplications]);

  const unreadCount = useMemo(() => messages.filter((item) => !item.read).length, [messages]);

  const value = useMemo<AppContextValue>(() => ({
    isBound,
    user,
    account,
    faceStatus,
    faceRejectReason,
    messages,
    notificationSettings,
    rechargeRecords,
    mealOrders,
    visitorRecords,
    attendanceApplications,
    unreadCount,
    bindAccount,
    unbindAccount,
    updatePhone,
    setAccountStatus,
    recharge,
    deduct,
    refund,
    setFaceReviewing,
    setFaceResult,
    markMessageRead,
    markAllMessagesRead,
    toggleNotification,
    addMealOrder,
    cancelMealOrder,
    addVisitorRecord,
    approveVisitor,
    rejectVisitor,
    signOutVisitor,
    addAttendanceApplication,
    refreshProfile,
    refreshRechargeRecords,
    refreshMealOrders,
    refreshAttendanceApplications,
    refreshVisitorRecords,
    refreshMessages,
  }), [
    isBound,
    user,
    account,
    faceStatus,
    faceRejectReason,
    messages,
    notificationSettings,
    rechargeRecords,
    mealOrders,
    visitorRecords,
    attendanceApplications,
    unreadCount,
    bindAccount,
    unbindAccount,
    updatePhone,
    setAccountStatus,
    recharge,
    deduct,
    refund,
    setFaceReviewing,
    setFaceResult,
    markMessageRead,
    markAllMessagesRead,
    toggleNotification,
    addMealOrder,
    cancelMealOrder,
    addVisitorRecord,
    approveVisitor,
    rejectVisitor,
    signOutVisitor,
    addAttendanceApplication,
    refreshProfile,
    refreshRechargeRecords,
    refreshMealOrders,
    refreshAttendanceApplications,
    refreshVisitorRecords,
    refreshMessages,
  ]);

  return <AppContext.Provider value={value}>{children}</AppContext.Provider>;
}

export function useApp(): AppContextValue {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}
