import React, { useEffect, useState } from 'react';
import { DotLoading } from 'antd-mobile';
import { getToken, setToken, m } from '../lib/api';

// 公众号 AppId：优先取 Vite 环境变量（.env 中配置 VITE_WX_APP_ID），否则用占位符
const WX_APPID = ((import.meta as any).env?.VITE_WX_APP_ID as string) || '';
const REDIRECT_PATH = '#/wx-oauth';

// 微信 OAuth2 授权回调页（snsapi_base 静默授权，仅服务号 H5 在微信内使用）
// 流程：带 code 进入 → 存 sessionStorage('ylt-wx-code') → 已绑定直接登录跳首页，未绑定去绑定页
export default function WxOauth(): React.JSX.Element {
  const [tip, setTip] = useState('微信授权中…');

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const code = params.get('code');
    const state = params.get('state') || '/';
    const redirect = state.startsWith('/') ? state : '/';

    if (!code) {
      // 无 code：拼接授权链接并跳转（仅微信内有效；非微信环境提示手动登录）
      const isWechat = /MicroMessenger/i.test(window.navigator.userAgent);
      if (!isWechat || !WX_APPID) {
        setTip('请在微信中打开，或直接使用工号+卡密码登录');
        window.setTimeout(() => { window.location.hash = '#/bind-account'; }, 1200);
        return;
      }
      const redirectUri = encodeURIComponent(`${window.location.origin}${window.location.pathname}${REDIRECT_PATH}`);
      const oauthUrl = `https://open.weixin.qq.com/connect/oauth2/authorize?appid=${WX_APPID}`
        + `&redirect_uri=${redirectUri}&response_type=code&scope=snsapi_base&state=${encodeURIComponent(redirect)}#wechat_redirect`;
      window.sessionStorage.setItem('ylt-wx-redirect', redirect);
      window.location.replace(oauthUrl);
      //setTip(oauthUrl);
      return;
    }
    // 拿到 code：先尝试静默登录（已绑定 OpenID 则直接发 Token）
    window.sessionStorage.setItem('ylt-wx-code', code);
    const fallbackRedirect = window.sessionStorage.getItem('ylt-wx-redirect') || redirect;
    m.wxLogin(code).then((res: any) => {
      if (res && res.success) {
        setToken(res.access_token);
        window.location.hash = fallbackRedirect;
        return;
      }
      if (res && res.needBind) {
        // 保存后端返回的 openid，供绑定使用
        window.sessionStorage.setItem('ylt-wx-openid', res.openid || '');
        window.sessionStorage.setItem('ylt-wx-unionid', res.unionid || '');
        // 清除已用过的 code，防止重复兑换
        window.sessionStorage.removeItem('ylt-wx-code');
      }
      // 未绑定：去绑定页（绑定成功后后端会顺带写入 OpenID，附加7）
      window.location.hash = '#/bind-account';
    }).catch(() => {
      window.location.hash = '#/bind-account';
    });
  }, []);

  return (
    <div className="min-h-screen bg-[#F5F7FA] flex flex-col items-center justify-center gap-3">
      <DotLoading color="primary" />
      <span className="text-xs text-gray-400">{tip}</span>
    </div>
  );
}
