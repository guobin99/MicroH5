import React, { useEffect, useMemo, useState } from 'react';
import { useLocation } from 'wouter';
import { Button, Card, Empty, NavBar, PullToRefresh, Tag, Toast } from 'antd-mobile';
import { CheckCircleOutlined, CloseCircleOutlined, GatewayOutlined, WarningOutlined } from '@ant-design/icons';
import TimeRangeFilter, { matchTimeRange, type TimeRange } from '../components/TimeRangeFilter';
import { m } from '../lib/api';

const doorOptions = ['全部', '东门门禁', '办公楼大厅', '食堂入口', '档案室', '宿舍区西门'];

// 附加8：正常/异常通行记录从后端获取（通行方式/异常原因由后端关联 MJ_EventInfo）
export default function AccessRecords(): React.JSX.Element {
  const [, setLocation] = useLocation();
  const [range, setRange] = useState<TimeRange>('7d');
  const [start, setStart] = useState('');
  const [end, setEnd] = useState('');
  const [door, setDoor] = useState('全部');
  const [visibleCount, setVisibleCount] = useState(5);
  const [records, setRecords] = useState<any[]>([]);

  const load = async (): Promise<void> => {
    try {
      const fmt = (d: Date) => {
        const p = (n: number) => String(n).padStart(2, '0');
        return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
      };
      const now = new Date();
      const bgn = range === 'custom' && start ? start : fmt(new Date(now.getTime() - 30 * 864e5));
      const endD = range === 'custom' && end ? end : fmt(now);
      const [n, a] = await Promise.all([m.accessNormal(bgn, endD), m.accessAbnorm(bgn, endD)]);
      const rows = [
        ...(Array.isArray(n) ? n : []).map((r: any) => ({
          id: 'N' + r.id,
          time: (r.time || '').replace('T', ' ').substring(0, 16),
          door: r.door || '',
          method: r.passType || '刷卡',
          result: 'success',
          reason: '',
        })),
        ...(Array.isArray(a) ? a : []).map((r: any) => ({
          id: 'A' + r.id,
          time: (r.time || '').replace('T', ' ').substring(0, 16),
          door: r.door || '',
          method: '',
          result: r.reason && r.reason.indexOf('权限') >= 0 ? 'denied' : 'offline',
          reason: r.reason || '',
        })),
      ].sort((x, y) => (x.time < y.time ? 1 : -1));
      setRecords(rows);
    } catch {
      Toast.show({ content: '加载失败' });
    }
  };

  useEffect(() => { load(); }, [range, start, end]); // eslint-disable-line react-hooks/exhaustive-deps

  const filtered = useMemo(() => records.filter((record) =>
    matchTimeRange(record.time, range, start, end) && (door === '全部' || record.door === door),
  ), [records, door, end, range, start]);
  const visible = filtered.slice(0, visibleCount);

  const resultMap: Record<string, { text: string; color: string; icon: React.JSX.Element }> = {
    success: { text: '通行成功', color: 'success', icon: <CheckCircleOutlined /> },
    denied: { text: '无权限', color: 'danger', icon: <CloseCircleOutlined /> },
    offline: { text: '异常', color: 'warning', icon: <WarningOutlined /> },
  };

  return (
    <div className="min-h-screen bg-[#F5F7FA]">
      <NavBar onBack={() => setLocation('/pass-code')} className="bg-white">门禁通行记录</NavBar>
      <TimeRangeFilter range={range} start={start} end={end} onRangeChange={setRange} onStartChange={setStart} onEndChange={setEnd} />

      <div className="bg-white px-4 py-3 flex gap-2 overflow-x-auto">
        {doorOptions.map((item) => (
          <Button
            key={item}
            size="mini"
            className={door === item ? '!bg-[#0064E6] !text-white !border-[#0064E6]' : '!bg-gray-100 !border-0 !text-gray-600'}
            onClick={() => setDoor(item)}
          >
            {item}
          </Button>
        ))}
      </div>

      <PullToRefresh onRefresh={async () => { await load(); setVisibleCount(5); }}>
        <div className="p-4 pb-6">
          {visible.length > 0 ? (
            <div className="space-y-3">
              {visible.map((record) => {
                const meta = resultMap[record.result];
                return (
                  <Card key={record.id} className="!rounded-2xl">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`w-11 h-11 rounded-2xl flex items-center justify-center text-xl ${record.result === 'success' ? 'bg-green-50 text-green-600' : record.result === 'denied' ? 'bg-red-50 text-red-500' : 'bg-orange-50 text-orange-500'}`}>
                          {meta.icon}
                        </div>
                        <div>
                          <div className="font-semibold text-gray-900">{record.door}</div>
                          <div className="text-xs text-gray-400 mt-1">{record.time} · {record.method}</div>
                        </div>
                      </div>
                      <Tag color={meta.color} fill="outline">{meta.text}</Tag>
                    </div>
                    {record.reason && <div className="mt-3 rounded-xl bg-gray-50 px-3 py-2 text-xs text-gray-500">原因:{record.reason}</div>}
                  </Card>
                );
              })}
            </div>
          ) : (
            <Empty image={<GatewayOutlined className="text-6xl text-gray-300" />} description="暂无通行记录" className="mt-20" />
          )}

          {visibleCount < filtered.length && (
            <Button block fill="outline" className="mt-4" onClick={() => setVisibleCount((value) => value + 5)}>
              加载更多
            </Button>
          )}
        </div>
      </PullToRefresh>
    </div>
  );
}
