// 后端 API 客户端（H5 服务号 / 微信小程序 共用同一套后端接口）
const BASE = import.meta.env.VITE_API_BASE_URL+ '/api';

export function getToken(): string {
  return localStorage.getItem('ylt-token') || '';
}
export function setToken(t: string): void {
  if (t) localStorage.setItem('ylt-token', t);
  else localStorage.removeItem('ylt-token');
}

export async function api(path: string, opts: any = {}): Promise<any> {
  //alert(BASE + path);
  const r = await fetch(BASE + path, {
    method: opts.method || 'GET',
    headers: {
      'Content-Type': 'application/json',
      Authorization: 'Bearer ' + getToken(),
      ...(opts.headers || {}),
    },
    body: opts.body ? JSON.stringify(opts.body) : undefined,
  });  
  if (r.status === 401) {
    setToken('');
    location.hash = '#/bind-account';
    throw new Error('登录已过期');
  }
  return r.json();
}

export const m = {
  // 认证（附加5：Person_No + Card_Password）
  login: (PersonNo: string, Password: string) =>
    api('/m/auth/login', { method: 'POST', body: { PersonNo, Password } }),
  sendSms: (mobile: string, scene: string) =>
    api(`/m/auth/smscode?mobile=${encodeURIComponent(mobile)}&scene=${scene}`),
  smsLogin: (mobile: string, code: string) =>
    api('/m/auth/smslogin', { method: 'POST', body: { Mobile: mobile, Code: code, Scene: 'h5' } }),
  wxLogin: (code: string) => api('/m/auth/wxlogin', { method: 'POST', body: { Code: code, Scene: 'h5' } }),
  bind: (b: any) => api('/m/auth/bind', { method: 'POST', body: { ...b, Scene: 'h5' } }),
  unbind: () => api('/m/auth/unbind', { method: 'POST', body: { Scene: 'h5' } }),
  profile: () => api('/m/auth/profile'),

  // 帐户
  changePwd: (oldPassword: string, newPassword: string) =>
    api('/m/account/changepwd', { method: 'POST', body: { oldPassword, newPassword } }),
  changePhone: (mobile: string, code: string) =>
    api('/m/account/changephone', { method: 'POST', body: { mobile, code } }),
  resetPwd: (mobile: string, code: string, idNumber: string, newPassword: string) =>
    api('/m/account/resetpwd', { method: 'POST', body: { mobile, code, idNumber, newPassword } }),
  // 充值记录报表（ST_SupplyFund）：按充值时间区间查询，逻辑与 consumptions 一致
  rechargeRecords: (bgn = '', end = '') =>
    api(`/m/account/rechargerecords?bgn=${encodeURIComponent(bgn)}&end=${encodeURIComponent(end)}`),
  // 消费记录报表（XF_Consume）：按消费时间区间查询
  consumptions: (bgn = '', end = '', page = 1) =>
    api(`/m/account/consumptions?bgn=${encodeURIComponent(bgn)}&end=${encodeURIComponent(end)}&page=${page}`),

  // 充值（附加1：真实微信支付 JSAPI → 异步通知 → 查询兜底）
  rechargeCreate: (amount: number) => api('/m/recharge/create', { method: 'POST', body: { amount, scene: 'h5' } }),
  rechargeQuery: (outTradeNo: string) => api('/m/recharge/query?outTradeNo=' + outTradeNo),

  // 通行记录（附加8）
  accessNormal: (bgn: string, end: string) => api(`/m/access/normal?bgn=${bgn}&end=${end}`),
  accessAbnorm: (bgn: string, end: string) => api(`/m/access/abnorm?bgn=${bgn}&end=${end}`),

  // 考勤（附加10/11）
  attendance: (bgn: string, end: string) => api(`/m/attendance/daily?bgn=${bgn}&end=${end}`),

  // 请假（附加9）
  leaveKinds: () => api('/m/leave/kinds'),
  leaveList: () => api('/m/leave/list'),
  leaveSubmit: (b: any) => api('/m/leave/submit', { method: 'POST', body: b }),

  // 付款码/通行码（附加3）
  payCode: () => api('/m/scancode/payment'),
  passCode: () => api('/m/scancode/pass'),

  // 人脸（附加12）
  faceUpload: (photo: string) => api('/m/face/upload', { method: 'POST', body: { photo } }),

  // 食堂订餐（附加13）
  areas: () => api('/m/canteen/areas'),
  repasts: () => api('/m/canteen/repasts'),
  menu: (week: number, repastNo: string, areaNo: string) =>
    api(`/m/canteen/menu?week=${week}&repastNo=${encodeURIComponent(repastNo)}&areaNo=${encodeURIComponent(areaNo)}`),
  todayMenu: () => api('/m/canteen/today'),
  // 订餐模式：'1'=订餐扣款（下单即扣），'0'=消费扣款（取餐时扣）
  orderMode: () => api('/m/canteen/ordermode'),
  order: (b: any) => api('/m/canteen/order', { method: 'POST', body: b }),
  myOrders: (bgn = '', end = '') =>
    api(`/m/canteen/myorders?bgn=${encodeURIComponent(bgn)}&end=${encodeURIComponent(end)}`),
  cancelOrder: (orderNo: string) => api('/m/canteen/cancel', { method: 'POST', body: { orderNo } }),

  // 消息中心（WX_Message）
  messageList: (page = 1) => api(`/m/message/list?page=${page}`),
  messageRead: (id: string) => api('/m/message/read', { method: 'POST', body: { id } }),
  messageReadAll: () => api('/m/message/readall', { method: 'POST', body: {} }),

  // 考勤补签/申诉（KQ_FillAttend / WX_KQ_Appeal）
  attapplyList: () => api('/m/attapply/list'),
  attapplyResignCount: () => api('/m/attapply/resign-count'),
  attapplyResign: (b: any) => api('/m/attapply/resign', { method: 'POST', body: b }),
  attapplyAppeal: (b: any) => api('/m/attapply/appeal', { method: 'POST', body: b }),

  // 访客预约（VisitorApply）
  visitorList: () => api('/m/visitor/list'),
  visitorSubmit: (b: any) => api('/m/visitor/submit', { method: 'POST', body: b }),
  visitorApprove: (id: string) => api('/m/visitor/approve', { method: 'POST', body: { id } }),
  visitorReject: (id: string, reason: string) => api('/m/visitor/reject', { method: 'POST', body: { id, reason } }),
  visitorSignOut: (id: string) => api('/m/visitor/signout', { method: 'POST', body: { id } }),
};

declare global {
  interface Window {
    WeixinJSBridge?: any;
  }
}
