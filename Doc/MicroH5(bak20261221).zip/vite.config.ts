import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  // server: {
  //   proxy: {
  //     '/api': { target: 'http://ad.wisdor.cn:8090', changeOrigin: true },            
  //   },
  // },
});